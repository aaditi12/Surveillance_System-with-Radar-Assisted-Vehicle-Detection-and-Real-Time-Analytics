#!/usr/bin/env bash
# Fixes the "_ARRAY_API not found" cv_bridge crash caused by numpy 2.x.
# cv_bridge on ROS 2 Humble is compiled against the numpy 1.x ABI.
# Pinning numpy alone leaves opencv-python/opencv-contrib-python (which
# require numpy>=2) mismatched, so pin all three together.
set -e
pip3 install "numpy<2" "opencv-python==4.9.0.80" "opencv-contrib-python==4.9.0.80" \
    --force-reinstall --break-system-packages
python3 -c "import cv2, numpy; from cv_bridge import CvBridge; print('OK:', cv2.__version__, numpy.__version__)"
