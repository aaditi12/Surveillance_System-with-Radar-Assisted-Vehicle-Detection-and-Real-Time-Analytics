#!/usr/bin/python3
import os
import launch, launch_ros
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.substitutions import LaunchConfiguration
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():

  pkg_testbed_gazebo = get_package_share_directory('testbed_gazebo')

  spawn_drone = LaunchConfiguration('spawn_drone')

  gazebo = IncludeLaunchDescription(
    PythonLaunchDescriptionSource(
      os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_playground.launch.py'),
    )
  )

  # Ground robot: robot_state_publisher + spawn, namespaced under "ground_robot"
  # robot_name is passed explicitly here -- LaunchConfiguration('robot_name')
  # is a single global variable across this whole launch tree, not scoped
  # per-include, so leaving it to each include's own default would let the
  # ground_robot include's default ('ground_robot') stick around and get
  # picked up by the drone include below too (DeclareLaunchArgument only
  # applies its default if the configuration isn't already set), causing
  # both entities to spawn under the same name and the second spawn to fail.
  ground_robot = IncludeLaunchDescription(
    PythonLaunchDescriptionSource(
      os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_ground_robot.launch.py'),
    ),
    launch_arguments={'robot_name': 'ground_robot'}.items(),
  )

  # Surveillance drone: robot_state_publisher + spawn, namespaced under "drone".
  # Spawns directly above the ground robot's spawn point so it starts out
  # hovering over what it's meant to surveil.
  # Toggle off with: spawn_drone:=false
  drone = IncludeLaunchDescription(
    PythonLaunchDescriptionSource(
      os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_drone.launch.py'),
    ),
    launch_arguments={'robot_name': 'drone', 'x': '0.0', 'y': '5.0', 'z': '3.0'}.items(),
    condition=IfCondition(spawn_drone),
  )

  rviz_config_dir = os.path.join(
    launch_ros.substitutions.FindPackageShare(package='testbed_description').find('testbed_description'),
    'rviz/testbed_rviz.rviz')

  rviz_node = Node(
    package='rviz2',
    executable='rviz2',
    name='rviz_node',
    parameters=[{'use_sim_time': True}],
    arguments=['-d', LaunchConfiguration('rvizconfig')]
  )

  return LaunchDescription([
    DeclareLaunchArgument(name='rvizconfig', default_value=rviz_config_dir,
                          description='Absolute path to rviz config file'),
    DeclareLaunchArgument(name='spawn_drone', default_value='true',
                          description='Whether to also spawn the surveillance drone'),
    gazebo,
    ground_robot,
    drone,
    rviz_node,
  ])
