#!/usr/bin/python3
"""
multi_robot_surveillance.launch.py

One-command bringup for the 4-ground-robot + 1-drone surveillance demo:

  - Spawns 4 ground robots (ground_robot1..4) at spread-out points along
    the city world's two roads, each with a map -> <ns>/odom static
    transform (fixed at its spawn pose) so all robots register into a
    common "map" frame in RViz, the same trick already used for the drone.
  - Spawns the surveillance drone above the city center.
  - Starts a ground_patrol.py process per robot, each driving its own
    square patrol loop at the *same* --speed (see `robot_speed` arg), so
    all four move at identical velocity on independent routes.
  - Starts drone_multi_survey.py, which takes the drone up to altitude
    and round-robins overwatch across all four robots, dwelling over
    each in turn while continuously publishing every robot's position
    and orientation (not just the current one).
  - Starts multi_surveillance_station.py, the ATC-style dashboard
    (console + web radar scope at http://localhost:8080/) showing all
    four robots' position/heading/speed and which one is currently
    under overwatch.
  - Opens RViz with a config that overlays all 4 robots + drone as
    labelled, heading-arrow markers in the map frame.

Spawns and patrol/survey processes are staged with delays because
spawn_entity.py + robot_state_publisher + Gazebo physics settling all
need to complete before a namespace's /odom is reliably being published;
starting the patrol/survey controllers too early just means their first
several control-loop ticks silently no-op waiting on odom, but staging
them avoids piling every entity spawn into Gazebo at once on
resource-constrained hosts (e.g. a Raspberry Pi), which is what actually
causes spawn timeouts / physics hiccups.

Usage:
    ros2 launch testbed_bringup multi_robot_surveillance.launch.py
    ros2 launch testbed_bringup multi_robot_surveillance.launch.py robot_speed:=0.6 dwell:=5.0
    ros2 launch testbed_bringup multi_robot_surveillance.launch.py web_port:=9090
    ros2 launch testbed_bringup multi_robot_surveillance.launch.py rviz:=false
"""
import os

import launch_ros
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription,
                             TimerAction)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

# name, spawn x, spawn y, spawn yaw(rad), square patrol waypoints (x y pairs)
ROBOTS = [
    ('ground_robot1', 14.0, 0.0, 1.5708,
     [12.0, -1.0, 16.0, -1.0, 16.0, 1.0, 12.0, 1.0]),
    ('ground_robot2', -14.0, 0.0, -1.5708,
     [-16.0, -1.0, -12.0, -1.0, -12.0, 1.0, -16.0, 1.0]),
    ('ground_robot3', 0.0, 14.0, 3.1416,
     [-1.0, 12.0, 1.0, 12.0, 1.0, 16.0, -1.0, 16.0]),
    ('ground_robot4', 0.0, -14.0, 0.0,
     [-1.0, -16.0, 1.0, -16.0, 1.0, -12.0, -1.0, -12.0]),
]
CALLSIGNS = ['GRND01', 'GRND02', 'GRND03', 'GRND04']


def generate_launch_description():

    pkg_testbed_gazebo = get_package_share_directory('testbed_gazebo')

    robot_speed = LaunchConfiguration('robot_speed')
    drone_altitude = LaunchConfiguration('drone_altitude')
    dwell = LaunchConfiguration('dwell')
    web_port = LaunchConfiguration('web_port')
    rviz_enabled = LaunchConfiguration('rviz')

    ground_namespaces_csv = ','.join(name for name, *_ in ROBOTS)
    callsigns_csv = ','.join(CALLSIGNS)

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_playground.launch.py'),
        )
    )

    actions = [gazebo]

    # --- spawn all 4 ground robots + their map->odom static transforms ----
    # Staggered by 1.5s each so spawn_entity.py calls don't all pile onto
    # Gazebo in the same tick (see module docstring).
    for i, (name, x, y, yaw, _wps) in enumerate(ROBOTS):
        spawn = IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_ground_robot.launch.py'),
            ),
            launch_arguments={
                'robot_name': name, 'x': str(x), 'y': str(y), 'z': '0.0', 'yaw': str(yaw),
            }.items(),
        )
        map_to_odom = Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name=f'map_to_{name}_odom',
            output='screen',
            arguments=[str(x), str(y), '0.0', str(yaw), '0', '0', 'map', f'{name}/odom'],
        )
        actions.append(TimerAction(period=1.5 * i, actions=[spawn, map_to_odom]))

    # --- drone: spawn above the city center, after the ground robots -----
    drone_spawn_delay = 1.5 * len(ROBOTS) + 2.0
    drone = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_drone.launch.py'),
        ),
        launch_arguments={'robot_name': 'drone', 'x': '0.0', 'y': '0.0', 'z': '3.0'}.items(),
    )
    actions.append(TimerAction(period=drone_spawn_delay, actions=[drone]))

    # --- per-robot patrol controllers, all at the same --speed -----------
    patrol_delay = drone_spawn_delay + 6.0  # let robots + drone settle physically first
    for name, _x, _y, _yaw, wps in ROBOTS:
        patrol_node = Node(
            package='testbed_navigation',
            executable='ground_patrol.py',
            name=f'{name}_patrol',
            output='screen',
            arguments=[str(v) for v in wps] + [
                '--namespace', name,
                '--speed', robot_speed,
                '--loop',
            ],
        )
        actions.append(TimerAction(period=patrol_delay, actions=[patrol_node]))

    # --- drone round-robin surveillance -----------------------------------
    survey_delay = patrol_delay + 2.0
    drone_survey_node = Node(
        package='testbed_navigation',
        executable='drone_multi_survey.py',
        name='drone_multi_survey',
        output='screen',
        arguments=[
            '--drone-namespace', 'drone',
            '--ground-namespaces', ground_namespaces_csv,
            '--callsigns', callsigns_csv,
            '--altitude', drone_altitude,
            '--dwell', dwell,
        ],
    )
    actions.append(TimerAction(period=survey_delay, actions=[drone_survey_node]))

    # --- dashboard ----------------------------------------------------------
    station_node = Node(
        package='testbed_navigation',
        executable='multi_surveillance_station.py',
        name='multi_surveillance_station',
        output='screen',
        arguments=[
            '--ground-namespaces', ground_namespaces_csv,
            '--callsigns', callsigns_csv,
            '--drone-namespace', 'drone',
            '--web-port', web_port,
        ],
    )
    actions.append(TimerAction(period=survey_delay, actions=[station_node]))

    # --- RViz --------------------------------------------------------------
    rviz_config = os.path.join(
        launch_ros.substitutions.FindPackageShare(package='testbed_description').find('testbed_description'),
        'rviz', 'multi_robot_surveillance.rviz')
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz_node',
        parameters=[{'use_sim_time': True}],
        arguments=['-d', rviz_config],
        condition=IfCondition(rviz_enabled),
    )
    actions.append(TimerAction(period=drone_spawn_delay, actions=[rviz_node]))

    return LaunchDescription([
        DeclareLaunchArgument('robot_speed', default_value='0.4',
                               description='Forward speed, m/s, shared by all 4 ground robots'),
        DeclareLaunchArgument('drone_altitude', default_value='10.0',
                               description='Drone overwatch altitude, m'),
        DeclareLaunchArgument('dwell', default_value='8.0',
                               description='Seconds the drone hovers over each robot before moving to the next'),
        DeclareLaunchArgument('web_port', default_value='8080',
                               description='Port for the radar-scope web dashboard'),
        DeclareLaunchArgument('rviz', default_value='true',
                               description='Whether to launch RViz'),
        *actions,
    ])
