#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
autonomous_patrol.launch.py

One-command autonomous demo: spawns both robots, brings up the ground
robot's full Nav2 stack, then starts two nodes that need no further
input from the user:

  - ground_auto_patrol.py  -- ground robot roams the map forever,
    picking random reachable goals and navigating to them via Nav2
    (full costmap-aware planning + obstacle avoidance).
  - drone_follow.py        -- drone takes off and follows the ground
    robot's live position, publishing the surveillance info screen
    (/surveillance/ground_robot_info, /surveillance/markers).

Stages are staggered with TimerAction so each dependency is up before
the next stage starts (Gazebo -> robots spawned -> localization/Nav2 ->
autonomous behavior nodes), same pattern used elsewhere in this
workspace to avoid startup race conditions.

Usage:
    ros2 launch testbed_bringup autonomous_patrol.launch.py

    # tune the drone's follow altitude / standoff, or skip the drone
    ros2 launch testbed_bringup autonomous_patrol.launch.py drone_altitude:=8.0 drone_standoff:=2.0
    ros2 launch testbed_bringup autonomous_patrol.launch.py spawn_drone:=false
"""
import os

import launch_ros
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription,
                             TimerAction)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_testbed_gazebo = get_package_share_directory('testbed_gazebo')
    pkg_testbed_navigation = get_package_share_directory('testbed_navigation')

    spawn_drone = LaunchConfiguration('spawn_drone')
    ground_namespace = LaunchConfiguration('ground_namespace')
    drone_namespace = LaunchConfiguration('drone_namespace')
    ground_initial_x = LaunchConfiguration('ground_initial_x')
    ground_initial_y = LaunchConfiguration('ground_initial_y')
    ground_initial_yaw = LaunchConfiguration('ground_initial_yaw')
    drone_altitude = LaunchConfiguration('drone_altitude')
    drone_spawn_altitude = LaunchConfiguration('drone_spawn_altitude')
    drone_standoff = LaunchConfiguration('drone_standoff')
    web_port = LaunchConfiguration('web_port')

    # Stage 0: Gazebo + world
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_playground.launch.py'),
        )
    )

    # Stage 0: robots (spawned right away too -- Gazebo comes up first in
    # practice via its own internal delays, and spawn_*.launch.py already
    # staggers its own spawn_entity/static-TF actions internally)
    ground_robot = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_ground_robot.launch.py'),
        ),
        launch_arguments={'robot_name': ground_namespace}.items(),
    )

    drone = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_drone.launch.py'),
        ),
        launch_arguments={
            'robot_name': drone_namespace,
            'z': drone_spawn_altitude,
        }.items(),
        condition=IfCondition(spawn_drone),
    )

    # Stage 1 (+25s): localization (map_server + AMCL) -- needs Gazebo/robot up first.
    # Widened from the original 6s: on pi-node1 gzserver + robot_state_publisher +
    # spawn can easily take 15-20s under load, and starting AMCL before /scan and
    # /ground_robot/map TF are actually flowing is why navigation silently never
    # activates when run as a single launch.
    localization = TimerAction(
        period=25.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg_testbed_navigation, 'launch', 'localization.launch.py'),
                ),
                launch_arguments={'robot_name': ground_namespace}.items(),
            ),
        ],
    )

    # Stage 2 (+40s): Nav2 planner/controller/BT stack -- needs localization fully
    # activated first (map_server + AMCL lifecycle transitions themselves take a
    # few seconds once they start, on top of however long they took to start).
    navigation = TimerAction(
        period=40.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg_testbed_navigation, 'launch', 'navigation.launch.py'),
                ),
                launch_arguments={'robot_name': ground_namespace}.items(),
            ),
        ],
    )

    # Stage 3 (+14s): the autonomous behaviors -- needs Nav2 active first.
    # aruco_ground_tracker does the actual camera-based detection;
    # drone_follow consumes its output, so both start together (drone_follow
    # just waits on the topics until the tracker publishes).
    ground_auto_patrol_node = Node(
        package='testbed_navigation',
        executable='ground_auto_patrol.py',
        name='ground_auto_patrol',
        output='screen',
        arguments=[
            '--namespace', ground_namespace,
            '--initial-pose', ground_initial_x, ground_initial_y, ground_initial_yaw,
        ],
    )

    aruco_tracker_node = Node(
        package='testbed_navigation',
        executable='aruco_ground_tracker.py',
        name='aruco_ground_tracker',
        output='screen',
        arguments=['--drone-namespace', drone_namespace],
        condition=IfCondition(spawn_drone),
    )

    drone_follow_node = Node(
        package='testbed_navigation',
        executable='drone_follow.py',
        name='drone_follow',
        output='screen',
        arguments=[
            '--drone-namespace', drone_namespace,
            '--altitude', drone_altitude,
            '--spawn-altitude', drone_spawn_altitude,
            '--standoff', drone_standoff,
        ],
        condition=IfCondition(spawn_drone),
    )

    surveillance_station_node = Node(
        package='testbed_navigation',
        executable='surveillance_station.py',
        name='surveillance_station',
        output='screen',
        arguments=[
            '--ground-namespace', ground_namespace,
            '--drone-namespace', drone_namespace,
            '--web-port', web_port,
        ],
        condition=IfCondition(spawn_drone),
    )

    autonomous_behaviors = TimerAction(
        period=55.0,
        actions=[ground_auto_patrol_node, aruco_tracker_node, drone_follow_node, surveillance_station_node],
    )

    rviz_config_dir = os.path.join(
        launch_ros.substitutions.FindPackageShare(package='testbed_description').find('testbed_description'),
        'rviz/full_bringup.rviz')

    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz_node',
        parameters=[{'use_sim_time': True}],
        arguments=['-d', LaunchConfiguration('rvizconfig')],
    )

    return LaunchDescription([
        DeclareLaunchArgument('rvizconfig', default_value=rviz_config_dir,
                              description='Absolute path to rviz config file'),
        DeclareLaunchArgument('spawn_drone', default_value='true',
                              description='Whether to also spawn + fly the surveillance drone'),
        DeclareLaunchArgument('ground_namespace', default_value='ground_robot'),
        DeclareLaunchArgument('drone_namespace', default_value='drone'),
        DeclareLaunchArgument('ground_initial_x', default_value='0.0',
                              description='AMCL initial x, must match the ground robot spawn pose'),
        DeclareLaunchArgument('ground_initial_y', default_value='5.0',
                              description='AMCL initial y, must match the ground robot spawn pose'),
        DeclareLaunchArgument('ground_initial_yaw', default_value='0.0',
                              description='AMCL initial yaw (degrees), must match the ground robot spawn pose'),
        DeclareLaunchArgument('drone_altitude', default_value='6.0'),
        DeclareLaunchArgument('drone_spawn_altitude', default_value='3.0'),
        DeclareLaunchArgument('drone_standoff', default_value='0.0'),
        DeclareLaunchArgument('web_port', default_value='8080',
                              description='Port for the surveillance station radar-scope web dashboard'),
        gazebo,
        ground_robot,
        drone,
        localization,
        navigation,
        autonomous_behaviors,
        rviz_node,
    ])
