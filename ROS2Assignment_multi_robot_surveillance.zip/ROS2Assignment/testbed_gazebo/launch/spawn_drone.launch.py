#!/usr/bin/python3
# -*- coding: utf-8 -*-
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction
from launch.substitutions import LaunchConfiguration
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def generate_launch_description():

    pkg_testbed_description = get_package_share_directory('testbed_description')
    pkg_testbed_gazebo = get_package_share_directory('testbed_gazebo')

    robot_name = LaunchConfiguration('robot_name')

    # Wrapped in a GroupAction so the PushRosNamespace inside
    # drone_description.launch.py doesn't leak into the spawn_testbed /
    # static_transform_publisher actions below (launch namespace pushes
    # are NOT scoped to the include they came from -- they leak to later
    # sibling actions in the same LaunchDescription otherwise).
    description = GroupAction([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_testbed_description, 'launch', 'drone_description.launch.py'),
            ),
            launch_arguments={'robot_name': robot_name}.items(),
        ),
    ])

    spawn = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_testbed.launch.py'),
        ),
        launch_arguments={
            'robot_name': robot_name,
            'x': LaunchConfiguration('x'),
            'y': LaunchConfiguration('y'),
            'z': LaunchConfiguration('z'),
            'yaw': LaunchConfiguration('yaw'),
        }.items(),
    )

    # The drone has no localization stack of its own (unlike the ground robot's
    # AMCL). It shares the ground robot's "map" frame via a static transform
    # from map -> drone/odom, fixed at the drone's spawn pose. The map frame is
    # assumed to coincide with the Gazebo world origin (true for this testbed
    # world/map pair). This is what stitches both robots' independent TF trees
    # together at "map".
    map_to_drone_odom = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='map_to_drone_odom',
        output='screen',
        arguments=[
            LaunchConfiguration('x'), LaunchConfiguration('y'), LaunchConfiguration('z'),
            LaunchConfiguration('yaw'), '0', '0',
            'map', [robot_name, '/odom'],
        ],
    )

    return LaunchDescription([
        DeclareLaunchArgument('robot_name', default_value='drone',
                               description='Namespace / TF-prefix for the drone'),
        DeclareLaunchArgument('x', default_value='-2.0'),
        DeclareLaunchArgument('y', default_value='5.0'),
        DeclareLaunchArgument('z', default_value='3.0',
                               description='Patrol altitude'),
        DeclareLaunchArgument('yaw', default_value='0.0'),
        description,
        spawn,
        map_to_drone_odom,
    ])
