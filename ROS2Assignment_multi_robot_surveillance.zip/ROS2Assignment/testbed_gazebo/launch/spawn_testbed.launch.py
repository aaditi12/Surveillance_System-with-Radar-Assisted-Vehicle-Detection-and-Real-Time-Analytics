#!/usr/bin/python3
# -*- coding: utf-8 -*-

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    robot_name = LaunchConfiguration('robot_name')
    x = LaunchConfiguration('x')
    y = LaunchConfiguration('y')
    z = LaunchConfiguration('z')
    yaw = LaunchConfiguration('yaw')

    # robot_state_publisher for this robot runs inside the robot_name
    # namespace (see robot_description.launch.py / drone_description.launch.py),
    # so /robot_description is published as /<robot_name>/robot_description.
    robot_description_topic = ['/', robot_name, '/robot_description']

    spawn_robot = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        name='spawn_entity',
        output='screen',
        arguments=['-entity', robot_name,
                   '-x', x, '-y', y, '-z', z,
                   '-R', '0', '-P', '0', '-Y', yaw,
                   '-topic', robot_description_topic,
                   '-timeout', '90',
                   ]
    )

    return LaunchDescription([
        DeclareLaunchArgument('robot_name', default_value='ground_robot',
                               description='Entity / namespace name to spawn'),
        DeclareLaunchArgument('x', default_value='0.0'),
        DeclareLaunchArgument('y', default_value='5.0'),
        DeclareLaunchArgument('z', default_value='0.0'),
        DeclareLaunchArgument('yaw', default_value='0.0'),
        spawn_robot,
    ])
