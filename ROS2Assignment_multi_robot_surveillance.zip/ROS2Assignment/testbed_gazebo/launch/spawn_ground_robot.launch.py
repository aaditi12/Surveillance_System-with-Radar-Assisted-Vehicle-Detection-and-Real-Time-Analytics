#!/usr/bin/python3
# -*- coding: utf-8 -*-
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction
from launch.substitutions import LaunchConfiguration
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource


def generate_launch_description():

    pkg_testbed_description = get_package_share_directory('testbed_description')
    pkg_testbed_gazebo = get_package_share_directory('testbed_gazebo')

    robot_name = LaunchConfiguration('robot_name')

    # Wrapped in a GroupAction so the PushRosNamespace inside
    # robot_description.launch.py doesn't leak into the spawn_testbed
    # include below (launch namespace pushes are otherwise NOT scoped
    # to the include they came from -- they leak to later sibling
    # actions in the same LaunchDescription).
    description = GroupAction([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_testbed_description, 'launch', 'robot_description.launch.py'),
            ),
            launch_arguments={'robot_name': robot_name}.items(),
        ),
    ])

    spawn = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_gazebo, 'launch', 'spawn_testbed.launch.py'),
        ),
        launch_arguments={
            'robot_name': robot_name,
            'x': LaunchConfiguration('x'),
            'y': LaunchConfiguration('y'),
            'z': LaunchConfiguration('z'),
            'yaw': LaunchConfiguration('yaw'),
        }.items(),
    )

    return LaunchDescription([
        DeclareLaunchArgument('robot_name', default_value='ground_robot',
                               description='Namespace / TF-prefix for the ground robot'),
        DeclareLaunchArgument('x', default_value='0.0'),
        DeclareLaunchArgument('y', default_value='5.0'),
        DeclareLaunchArgument('z', default_value='0.0'),
        DeclareLaunchArgument('yaw', default_value='0.0'),
        description,
        spawn,
    ])
