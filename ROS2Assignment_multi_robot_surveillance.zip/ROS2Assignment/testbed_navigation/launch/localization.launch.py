#!/usr/bin/env python3
"""
localization.launch.py

Brings up localization "manually" using the individual nav2 plugins:
  - nav2_map_server  (publishes the static /map)
  - nav2_amcl        (particle-filter localization against /scan + /map)
  - nav2_lifecycle_manager (drives both through configure -> activate)

AMCL needs the map, so this launch file owns its own map_server instance
rather than depending on map_loader.launch.py already running -- that keeps
this stage self-contained and independently testable, per step 5 of the
assignment ("Verify that the robot can localize itself ... using Rviz").

All nodes are pushed into the `robot_name` namespace (default
"ground_robot") so /scan and /map resolve under /ground_robot/... ,
matching the ground robot's namespaced Gazebo plugins. Frame ids in
amcl_params.yaml already carry the "ground_robot/" prefix as literal
strings, unaffected by this namespace push.

Usage:
    ros2 launch testbed_navigation localization.launch.py
    ros2 launch testbed_navigation localization.launch.py map:=/path/to/other_map.yaml
    ros2 launch testbed_navigation localization.launch.py robot_name:=other_robot
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node, PushRosNamespace


def generate_launch_description():
    pkg_testbed_navigation = get_package_share_directory('testbed_navigation')

    default_map_path = os.path.join(
        get_package_share_directory('testbed_bringup'),
        'maps',
        'testbed_world.yaml',
    )
    default_amcl_params = os.path.join(
        pkg_testbed_navigation, 'config', 'amcl_params.yaml'
    )

    map_yaml_file = LaunchConfiguration('map')
    amcl_params_file = LaunchConfiguration('params_file')
    use_sim_time = LaunchConfiguration('use_sim_time')
    autostart = LaunchConfiguration('autostart')
    robot_name = LaunchConfiguration('robot_name')

    declare_map_arg = DeclareLaunchArgument(
        'map',
        default_value=default_map_path,
        description='Full path to the map yaml file to load',
    )

    declare_params_arg = DeclareLaunchArgument(
        'params_file',
        default_value=default_amcl_params,
        description='Full path to the AMCL parameter file',
    )

    declare_use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='True',
        description='Use simulation (Gazebo) clock if true',
    )

    declare_autostart_arg = DeclareLaunchArgument(
        'autostart',
        default_value='True',
        description='Automatically bring map_server/amcl to the active state',
    )

    declare_robot_name_arg = DeclareLaunchArgument(
        'robot_name',
        default_value='ground_robot',
        description='Namespace to push map_server/amcl into, must match the spawned ground robot',
    )

    map_server_node = Node(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'yaml_filename': map_yaml_file,
        }],
    )

    amcl_node = Node(
        package='nav2_amcl',
        executable='amcl',
        name='amcl',
        output='screen',
        parameters=[amcl_params_file, {'use_sim_time': use_sim_time}],
    )

    lifecycle_manager_node = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_localization',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'autostart': autostart,
            'node_names': ['map_server', 'amcl'],
        }],
    )

    namespaced_localization = GroupAction([
        PushRosNamespace(robot_name),
        map_server_node,
        amcl_node,
        lifecycle_manager_node,
    ])

    return LaunchDescription([
        declare_map_arg,
        declare_params_arg,
        declare_use_sim_time_arg,
        declare_autostart_arg,
        declare_robot_name_arg,
        namespaced_localization,
    ])
