#!/usr/bin/env python3
"""
mapping_with_rviz.launch.py

Single-command SLAM mapping: brings up Gazebo (city world), the ground
robot + drone, RViz (testbed_rviz.rviz, which already has a Map display
on /map with Fixed Frame 'map'), and slam_toolbox (online-async) so the
occupancy grid streams into RViz live as the robot drives.

Equivalent to running testbed_full_bringup.launch.py + slam.launch.py in
two terminals, but as one command. Drive the robot manually
(teleop_twist_keyboard, or `ros2 launch testbed_navigation
manual_mapping.launch.py` in a second terminal for the built-in
teleop+map-save node) and watch the map build in RViz.

Usage:
    ros2 launch testbed_navigation mapping_with_rviz.launch.py
    ros2 launch testbed_navigation mapping_with_rviz.launch.py spawn_drone:=false
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    pkg_testbed_bringup = get_package_share_directory('testbed_bringup')
    pkg_testbed_navigation = get_package_share_directory('testbed_navigation')

    spawn_drone = LaunchConfiguration('spawn_drone')
    use_sim_time = LaunchConfiguration('use_sim_time')

    full_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_bringup, 'launch', 'testbed_full_bringup.launch.py')
        ),
        launch_arguments={'spawn_drone': spawn_drone}.items(),
    )

    slam = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_navigation, 'launch', 'slam.launch.py')
        ),
        launch_arguments={'use_sim_time': use_sim_time}.items(),
    )

    return LaunchDescription([
        DeclareLaunchArgument('spawn_drone', default_value='true',
                               description='Whether to also spawn the surveillance drone'),
        DeclareLaunchArgument('use_sim_time', default_value='True',
                               description='Use simulation (Gazebo) clock if true'),
        full_bringup,
        slam,
    ])
