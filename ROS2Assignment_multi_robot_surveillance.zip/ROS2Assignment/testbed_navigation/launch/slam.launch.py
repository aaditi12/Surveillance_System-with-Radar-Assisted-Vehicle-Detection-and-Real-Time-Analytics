#!/usr/bin/env python3
"""
slam.launch.py

Runs slam_toolbox in online-async mapping mode in place of
map_loader.launch.py + localization.launch.py. slam_toolbox builds the
occupancy grid live from /scan and publishes both /map and the
map -> odom transform, exactly like AMCL does against a fixed map -- so
navigation.launch.py (planner/controller/behavior/bt_navigator/
velocity_smoother) runs completely unchanged on top of it.

Usage:
    ros2 launch testbed_navigation slam.launch.py
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_testbed_navigation = get_package_share_directory('testbed_navigation')
    default_params_file = os.path.join(
        pkg_testbed_navigation, 'config', 'slam_toolbox_params.yaml'
    )

    params_file = LaunchConfiguration('params_file')
    use_sim_time = LaunchConfiguration('use_sim_time')

    declare_params_arg = DeclareLaunchArgument(
        'params_file',
        default_value=default_params_file,
        description='Full path to the slam_toolbox parameter file',
    )

    declare_use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='True',
        description='Use simulation (Gazebo) clock if true',
    )

    slam_toolbox_node = Node(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        output='screen',
        parameters=[params_file, {'use_sim_time': use_sim_time}],
    )

    return LaunchDescription([
        declare_params_arg,
        declare_use_sim_time_arg,
        slam_toolbox_node,
    ])
