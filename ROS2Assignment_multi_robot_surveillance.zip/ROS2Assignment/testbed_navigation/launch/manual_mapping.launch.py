#!/usr/bin/env python3
"""
manual_mapping.launch.py

Manual (teleop-driven) SLAM mapping, one command:
  - slam_toolbox (online async) builds /map live from /scan as you drive
  - teleop_mapper opens an interactive keyboard teleop in this terminal:
    WASD drives the robot, 'm' saves the finished map to disk, 'q' quits.

Usage:
    ros2 launch testbed_bringup testbed_full_bringup.launch.py   # terminal 1
    ros2 launch testbed_navigation manual_mapping.launch.py      # terminal 2 (interactive)
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_testbed_navigation = get_package_share_directory('testbed_navigation')

    use_sim_time = LaunchConfiguration('use_sim_time')
    map_save_path = LaunchConfiguration('map_save_path')

    declare_use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='True',
        description='Use simulation (Gazebo) clock if true',
    )

    declare_map_save_path_arg = DeclareLaunchArgument(
        'map_save_path',
        default_value='',
        description="Full path prefix to save the map to when 'm' is pressed "
                    "(default: ~/testbed_map_<timestamp>)",
    )

    slam = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_testbed_navigation, 'launch', 'slam.launch.py')
        ),
        launch_arguments={'use_sim_time': use_sim_time}.items(),
    )

    teleop_mapper_node = Node(
        package='testbed_navigation',
        executable='teleop_mapper.py',
        name='teleop_mapper',
        output='screen',
        emulate_tty=True,
        prefix='xterm -e',
        parameters=[{
            'use_sim_time': use_sim_time,
            'cmd_vel_topic': 'cmd_vel',
            'linear_speed': 0.2,
            'angular_speed': 0.6,
            'speed_step': 0.05,
            'map_save_path': map_save_path,
        }],
    )

    return LaunchDescription([
        declare_use_sim_time_arg,
        declare_map_save_path_arg,
        slam,
        teleop_mapper_node,
    ])
