#!/usr/bin/env python3
"""
drone_surveillance.launch.py

One command for "the drone follows the car wherever it goes": starts
drone_follow.py (default --source model_states, so it tracks the ground
robot's true Gazebo pose continuously -- no lost-track/hover gaps) plus
surveillance_station.py for the on-screen status dashboard.

Requires the ground robot and drone already spawned, e.g.:
    ros2 launch testbed_bringup testbed_full_bringup.launch.py

Usage:
    ros2 launch testbed_navigation drone_surveillance.launch.py
    ros2 launch testbed_navigation drone_surveillance.launch.py altitude:=8.0 standoff:=2.0
    ros2 launch testbed_navigation drone_surveillance.launch.py source:=aruco
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    altitude = LaunchConfiguration('altitude')
    standoff = LaunchConfiguration('standoff')
    source = LaunchConfiguration('source')
    drone_namespace = LaunchConfiguration('drone_namespace')

    drone_follow_node = Node(
        package='testbed_navigation',
        executable='drone_follow.py',
        name='drone_follow',
        output='screen',
        arguments=[
            '--drone-namespace', drone_namespace,
            '--source', source,
            '--altitude', altitude,
            '--standoff', standoff,
        ],
    )

    surveillance_station_node = Node(
        package='testbed_navigation',
        executable='surveillance_station.py',
        name='surveillance_station',
        output='screen',
        arguments=[
            '--drone-namespace', drone_namespace,
        ],
    )

    return LaunchDescription([
        DeclareLaunchArgument('altitude', default_value='6.0',
                               description='Follow altitude, m'),
        DeclareLaunchArgument('standoff', default_value='0.0',
                               description='Lateral standoff instead of hovering directly overhead, m'),
        DeclareLaunchArgument('source', default_value='model_states',
                               description="Tracking source: 'model_states' (ground truth, "
                                           "default) or 'aruco' (vision-based, requires "
                                           "aruco_ground_tracker.py running separately)"),
        DeclareLaunchArgument('drone_namespace', default_value='drone'),
        drone_follow_node,
        surveillance_station_node,
    ])
