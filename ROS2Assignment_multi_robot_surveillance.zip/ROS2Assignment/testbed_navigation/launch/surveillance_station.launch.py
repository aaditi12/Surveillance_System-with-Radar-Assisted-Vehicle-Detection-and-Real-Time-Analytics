#!/usr/bin/env python3
"""
surveillance_station.launch.py

Standalone launch for the ATC-style surveillance station, for when you
already have the ground robot, drone, and aruco_ground_tracker.py running
(e.g. via testbed_bringup/testbed_full_bringup.launch.py) and just want to
bring the "control tower" dashboard up or restart it on its own.

Usage:
    ros2 launch testbed_navigation surveillance_station.launch.py
    ros2 launch testbed_navigation surveillance_station.launch.py web_port:=9090
    ros2 launch testbed_navigation surveillance_station.launch.py no_web:=true
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    ground_namespace = LaunchConfiguration('ground_namespace')
    drone_namespace = LaunchConfiguration('drone_namespace')
    ground_callsign = LaunchConfiguration('ground_callsign')
    drone_callsign = LaunchConfiguration('drone_callsign')
    web_port = LaunchConfiguration('web_port')
    no_web = LaunchConfiguration('no_web')

    surveillance_station_node_noweb = Node(
        package='testbed_navigation',
        executable='surveillance_station.py',
        name='surveillance_station',
        output='screen',
        arguments=[
            '--ground-namespace', ground_namespace,
            '--drone-namespace', drone_namespace,
            '--ground-callsign', ground_callsign,
            '--drone-callsign', drone_callsign,
            '--no-web',
        ],
        condition=IfCondition(no_web),
    )

    return LaunchDescription([
        DeclareLaunchArgument('ground_namespace', default_value='ground_robot'),
        DeclareLaunchArgument('drone_namespace', default_value='drone'),
        DeclareLaunchArgument('ground_callsign', default_value='GRND01'),
        DeclareLaunchArgument('drone_callsign', default_value='DRONE01'),
        DeclareLaunchArgument('web_port', default_value='8080'),
        DeclareLaunchArgument('no_web', default_value='false',
                              description='Set true to disable the web dashboard (console/topic only)'),
        Node(
            package='testbed_navigation',
            executable='surveillance_station.py',
            name='surveillance_station',
            output='screen',
            arguments=[
                '--ground-namespace', ground_namespace,
                '--drone-namespace', drone_namespace,
                '--ground-callsign', ground_callsign,
                '--drone-callsign', drone_callsign,
                '--web-port', web_port,
            ],
            condition=UnlessCondition(no_web),
        ),
        surveillance_station_node_noweb,
    ])
