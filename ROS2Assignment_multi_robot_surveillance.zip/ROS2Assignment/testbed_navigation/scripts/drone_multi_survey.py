#!/usr/bin/env python3
"""
drone_multi_survey.py

Multi-target surveillance for the drone: instead of following one ground
robot forever, it round-robins overwatch across N ground robots --
flying to hover above each one in turn, dwelling there for a while, then
moving to the next -- while continuously reporting the position AND
orientation of *every* robot, not just the one it's currently over
(exactly like an ATC radar keeps every aircraft on scope, not just the
one the controller is currently speaking to).

Tracking source is each ground robot's own <namespace>/odom (position +
yaw + speed), the same source ground_patrol.py drives off of, so no
model_states name-matching is needed and namespaces are the only thing
that has to line up with how the robots were spawned.

Publishes:
  /surveillance/markers   (visualization_msgs/MarkerArray)
      For every robot: an ARROW at its current position/heading (shows
      orientation directly in RViz) + a TEXT label with callsign,
      position, and heading. The robot currently under active overwatch
      is highlighted (bright red arrow + sightline from the drone);
      the rest are shown dimmer (amber) so you can see all four on
      scope at once.
  /surveillance/current_target   (std_msgs/String)
      Namespace of the robot currently being surveilled, e.g. "ground_robot2".
  /surveillance/robots_report    (std_msgs/String, JSON)
      Array of {namespace, callsign, x, y, yaw_deg, speed_mps, is_target}
      for every tracked robot, for the web dashboard / any other consumer.
  /surveillance/ground_robot_info (std_msgs/String)
      One-line human-readable summary, same spirit as drone_follow.py.

Usage:
    ros2 run testbed_navigation drone_multi_survey.py \\
        --ground-namespaces ground_robot1,ground_robot2,ground_robot3,ground_robot4 \\
        --callsigns GRND01,GRND02,GRND03,GRND04 \\
        --altitude 10.0 --dwell 8.0

Notes:
    - Requires the drone and all ground robots already spawned.
    - Requires /gazebo/set_entity_state (gazebo_ros_state world plugin)
      for the kinematic takeoff/altitude hold, same as drone_patrol.py.
"""

import argparse
import json
import math
import sys
import time

import rclpy
from gazebo_msgs.msg import EntityState
from gazebo_msgs.srv import SetEntityState
from geometry_msgs.msg import Point, Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy
from std_msgs.msg import String
from visualization_msgs.msg import Marker, MarkerArray


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def parse_args(argv):
    parser = argparse.ArgumentParser(
        description='Round-robin drone surveillance across multiple ground robots.')
    parser.add_argument('--drone-namespace', default='drone',
                         help='Drone namespace / robot_name used at spawn (default: drone)')
    parser.add_argument('--ground-namespaces', default='ground_robot1,ground_robot2,ground_robot3,ground_robot4',
                         help='Comma-separated ground robot namespaces (default: '
                              'ground_robot1,ground_robot2,ground_robot3,ground_robot4)')
    parser.add_argument('--callsigns', default='',
                         help='Comma-separated display callsigns, same order/count as '
                              '--ground-namespaces. Default: GRND01, GRND02, ...')
    parser.add_argument('--altitude', type=float, default=10.0,
                         help='Patrol/overwatch altitude, m (default: 10.0)')
    parser.add_argument('--spawn-altitude', type=float, default=3.0,
                         help='Altitude the drone was spawned at, m (default: 3.0)')
    parser.add_argument('--climb-rate', type=float, default=0.5,
                         help='Vertical speed while taking off, m/s (default: 0.5)')
    parser.add_argument('--dwell', type=float, default=8.0,
                         help='Seconds to hover over each robot before moving to the next '
                              '(default: 8.0)')
    parser.add_argument('--arrival-tolerance', type=float, default=0.4,
                         help='Distance within which the drone counts as "overhead" and '
                              'starts the dwell timer, m (default: 0.4)')
    parser.add_argument('--max-transit', type=float, default=25.0,
                         help='Max seconds to chase a target before giving up and moving on '
                              'anyway, in case a robot is consistently out of reach (default: 25.0)')
    parser.add_argument('--speed', type=float, default=1.5,
                         help='Max lateral speed, m/s (default: 1.5)')
    parser.add_argument('--kp', type=float, default=0.8,
                         help='Proportional gain on position error (default: 0.8)')
    parser.add_argument('--report-rate', type=float, default=2.0,
                         help='Marker/report publish rate, Hz (default: 2.0)')
    args = parser.parse_args(argv)

    args.ground_namespaces = [n.strip() for n in args.ground_namespaces.split(',') if n.strip()]
    if args.callsigns.strip():
        args.callsigns = [c.strip() for c in args.callsigns.split(',') if c.strip()]
    else:
        args.callsigns = [f'GRND{i+1:02d}' for i in range(len(args.ground_namespaces))]
    if len(args.callsigns) != len(args.ground_namespaces):
        parser.error('--callsigns must have the same number of entries as --ground-namespaces')
    return args


class Track:
    """Live odometry state for one tracked ground robot."""
    def __init__(self, namespace, callsign):
        self.namespace = namespace
        self.callsign = callsign
        self.x = None
        self.y = None
        self.yaw = 0.0
        self.speed = 0.0


class DroneMultiSurvey(Node):

    def __init__(self, args):
        super().__init__('drone_multi_survey')
        self.args = args

        self.tracks = [Track(ns, cs) for ns, cs in zip(args.ground_namespaces, args.callsigns)]
        self.target_idx = 0
        self.arrived_since = None
        self.transit_start = time.monotonic()

        # drone state
        self.dx = None
        self.dy = None
        self.dqz = 0.0
        self.dqw = 1.0
        self.z = args.spawn_altitude
        self.takeoff_done = abs(args.altitude - args.spawn_altitude) < 1e-3

        best_effort_qos = QoSProfile(depth=10, reliability=QoSReliabilityPolicy.BEST_EFFORT)

        self.cmd_pub = self.create_publisher(Twist, f'/{args.drone_namespace}/cmd_vel', 10)
        self.drone_odom_sub = self.create_subscription(
            Odometry, f'/{args.drone_namespace}/odom', self.drone_odom_cb, best_effort_qos)
        self.set_state_client = self.create_client(SetEntityState, '/gazebo/set_entity_state')

        self._subs = []
        for t in self.tracks:
            sub = self.create_subscription(
                Odometry, f'/{t.namespace}/odom',
                (lambda msg, tt=t: self.ground_odom_cb(msg, tt)), best_effort_qos)
            self._subs.append(sub)

        self.marker_pub = self.create_publisher(MarkerArray, '/surveillance/markers', 10)
        self.target_pub = self.create_publisher(String, '/surveillance/current_target', 10)
        self.report_pub = self.create_publisher(String, '/surveillance/robots_report', 10)
        self.info_pub = self.create_publisher(String, '/surveillance/ground_robot_info', 10)

        self.get_logger().info(
            f'Drone "{args.drone_namespace}" surveilling {len(self.tracks)} ground robot(s): '
            f'{[t.callsign for t in self.tracks]}, altitude={args.altitude}m, dwell={args.dwell}s each.'
        )

        self.control_timer = self.create_timer(0.1, self.control_loop)
        self.report_timer = self.create_timer(1.0 / args.report_rate, self.report_loop)

    def drone_odom_cb(self, msg):
        self.dx = msg.pose.pose.position.x
        self.dy = msg.pose.pose.position.y
        self.dqz = msg.pose.pose.orientation.z
        self.dqw = msg.pose.pose.orientation.w

    def ground_odom_cb(self, msg, track):
        p = msg.pose.pose.position
        track.x = p.x
        track.y = p.y
        track.yaw = yaw_from_quaternion(msg.pose.pose.orientation)
        v = msg.twist.twist.linear
        track.speed = math.hypot(v.x, v.y)

    def stop(self):
        self.cmd_pub.publish(Twist())

    def set_altitude(self, z):
        if not self.set_state_client.service_is_ready():
            return
        req = SetEntityState.Request()
        req.state = EntityState()
        req.state.name = self.args.drone_namespace
        req.state.pose.position.x = self.dx
        req.state.pose.position.y = self.dy
        req.state.pose.position.z = z
        req.state.pose.orientation.z = self.dqz
        req.state.pose.orientation.w = self.dqw
        req.state.reference_frame = 'world'
        self.set_state_client.call_async(req)
        self.z = z

    def current_track(self):
        return self.tracks[self.target_idx]

    def advance_target(self):
        self.target_idx = (self.target_idx + 1) % len(self.tracks)
        self.arrived_since = None
        self.transit_start = time.monotonic()
        self.get_logger().info(
            f'Switching overwatch -> {self.current_track().callsign} '
            f'({self.current_track().namespace})')

    def control_loop(self):
        if self.dx is None:
            return  # waiting on drone odom

        if not self.takeoff_done:
            target_z = self.args.altitude
            step = self.args.climb_rate * 0.1
            if target_z > self.z:
                self.z = min(target_z, self.z + step)
            else:
                self.z = max(target_z, self.z - step)
            self.set_altitude(self.z)
            if abs(self.z - target_z) < 0.02:
                self.takeoff_done = True
                self.get_logger().info(f'Reached overwatch altitude {target_z:.1f}m, starting surveillance sweep.')
            return

        target = self.current_track()
        if target.x is None:
            return  # no odom yet from the current target

        ex, ey = target.x - self.dx, target.y - self.dy
        dist = math.hypot(ex, ey)

        now = time.monotonic()
        if dist <= self.args.arrival_tolerance:
            if self.arrived_since is None:
                self.arrived_since = now
                self.get_logger().info(f'Overhead {target.callsign}, dwelling {self.args.dwell:.1f}s.')
            if now - self.arrived_since >= self.args.dwell:
                self.advance_target()
                return
        elif now - self.transit_start > self.args.max_transit:
            self.get_logger().warn(f'{target.callsign} out of reach too long, moving on.')
            self.advance_target()
            return

        vx = max(-self.args.speed, min(self.args.speed, self.args.kp * ex))
        vy = max(-self.args.speed, min(self.args.speed, self.args.kp * ey))
        cmd = Twist()
        cmd.linear.x = vx
        cmd.linear.y = vy
        self.cmd_pub.publish(cmd)

    def report_loop(self):
        if all(t.x is None for t in self.tracks):
            return

        stamp = self.get_clock().now().to_msg()
        drone_x = self.dx if self.dx is not None else 0.0
        drone_y = self.dy if self.dy is not None else 0.0
        target = self.current_track()

        self.target_pub.publish(String(data=target.namespace))

        report = []
        markers = MarkerArray()
        mid = 0
        for t in self.tracks:
            is_target = (t is target)
            report.append({
                'namespace': t.namespace,
                'callsign': t.callsign,
                'x': round(t.x, 3) if t.x is not None else None,
                'y': round(t.y, 3) if t.y is not None else None,
                'yaw_deg': round(math.degrees(t.yaw) % 360.0, 1) if t.x is not None else None,
                'speed_mps': round(t.speed, 2) if t.x is not None else None,
                'is_target': is_target,
            })
            if t.x is None:
                continue

            color = (1.0, 0.15, 0.15) if is_target else (1.0, 0.75, 0.1)

            arrow = Marker()
            arrow.header.frame_id = 'map'
            arrow.header.stamp = stamp
            arrow.ns = 'surveillance'
            arrow.id = mid; mid += 1
            arrow.type = Marker.ARROW
            arrow.action = Marker.ADD
            arrow.pose.position.x = t.x
            arrow.pose.position.y = t.y
            arrow.pose.position.z = 0.15
            arrow.pose.orientation.z = math.sin(t.yaw / 2.0)
            arrow.pose.orientation.w = math.cos(t.yaw / 2.0)
            arrow.scale.x, arrow.scale.y, arrow.scale.z = 0.8, 0.15, 0.15
            arrow.color.r, arrow.color.g, arrow.color.b = color
            arrow.color.a = 1.0
            markers.markers.append(arrow)

            label = Marker()
            label.header.frame_id = 'map'
            label.header.stamp = stamp
            label.ns = 'surveillance'
            label.id = mid; mid += 1
            label.type = Marker.TEXT_VIEW_FACING
            label.action = Marker.ADD
            label.pose.position.x = t.x
            label.pose.position.y = t.y
            label.pose.position.z = 1.2
            label.scale.z = 0.4
            label.color.r, label.color.g, label.color.b = color
            label.color.a = 1.0
            tag = f'{t.callsign} [OVERWATCH]' if is_target else t.callsign
            label.text = f'{tag}\n({t.x:.2f}, {t.y:.2f}) hdg={math.degrees(t.yaw)%360:.0f}deg'
            markers.markers.append(label)

            if is_target:
                sightline = Marker()
                sightline.header.frame_id = 'map'
                sightline.header.stamp = stamp
                sightline.ns = 'surveillance'
                sightline.id = mid; mid += 1
                sightline.type = Marker.LINE_STRIP
                sightline.action = Marker.ADD
                sightline.scale.x = 0.05
                sightline.color.r, sightline.color.g, sightline.color.b = (1.0, 0.8, 0.0)
                sightline.color.a = 0.8
                sightline.points = [Point(x=drone_x, y=drone_y, z=self.z), Point(x=t.x, y=t.y, z=0.1)]
                markers.markers.append(sightline)

        self.marker_pub.publish(markers)
        self.report_pub.publish(String(data=json.dumps(report)))

        status = ' | '.join(
            f"{r['callsign']}@({r['x']},{r['y']}) hdg={r['yaw_deg']}deg v={r['speed_mps']}m/s"
            + ('*' if r['is_target'] else '')
            for r in report if r['x'] is not None
        )
        self.info_pub.publish(String(data=status))
        self.get_logger().info(status)


def main(args=None):
    raw = rclpy.utilities.remove_ros_args(sys.argv)[1:]
    parsed = parse_args(raw)

    rclpy.init(args=args)
    node = DroneMultiSurvey(parsed)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
