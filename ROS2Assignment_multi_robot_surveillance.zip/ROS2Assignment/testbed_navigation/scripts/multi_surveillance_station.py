#!/usr/bin/env python3
"""
multi_surveillance_station.py

Multi-target version of surveillance_station.py: an ATC-style "control
tower" dashboard that keeps every ground robot on scope at once, instead
of just one. Consumes each ground robot's own odometry directly (always
available -- no vision drop-out to coast/lose), the drone's odometry, and
optionally drone_multi_survey.py's /surveillance/current_target topic to
know exactly which robot is under active overwatch right now.

Provides:
  1. A console contact report (all tracks) at --report-rate.
  2. /surveillance/station_report (std_msgs/String, JSON) -- list of all
     tracks with position, heading, speed, range/bearing from the drone,
     and overwatch status.
  3. An optional live web "radar scope" (Flask) showing all robots as
     blips + a heading tick, the currently-overwatched one highlighted,
     plus a data table with position/heading/speed for every robot.
     Open http://<host>:<port>/ once running. Disable with --no-web.

Usage:
    ros2 run testbed_navigation multi_surveillance_station.py
    ros2 run testbed_navigation multi_surveillance_station.py \\
        --ground-namespaces ground_robot1,ground_robot2,ground_robot3,ground_robot4 \\
        --callsigns GRND01,GRND02,GRND03,GRND04 --web-port 8080
"""

import argparse
import json
import math
import sys
import threading
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy

from std_msgs.msg import String
from nav_msgs.msg import Odometry


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def parse_args(argv):
    parser = argparse.ArgumentParser(
        description='ATC-style multi-robot surveillance station: consolidated contact reports '
                    '+ radar-scope web view for N ground robots watched by one drone.')
    parser.add_argument('--ground-namespaces', default='ground_robot1,ground_robot2,ground_robot3,ground_robot4',
                         help='Comma-separated ground robot namespaces (default: '
                              'ground_robot1,ground_robot2,ground_robot3,ground_robot4)')
    parser.add_argument('--callsigns', default='',
                         help='Comma-separated display callsigns, same order/count as '
                              '--ground-namespaces. Default: GRND01, GRND02, ...')
    parser.add_argument('--drone-namespace', default='drone',
                         help='Namespace of the overwatch drone (default: drone)')
    parser.add_argument('--drone-callsign', default='DRONE01',
                         help='Display callsign for the drone (default: DRONE01)')
    parser.add_argument('--report-rate', type=float, default=1.0,
                         help='Console contact-report rate in Hz (default: 1.0)')
    parser.add_argument('--web-port', type=int, default=8080,
                         help='Port for the radar-scope web dashboard (default: 8080)')
    parser.add_argument('--no-web', action='store_true',
                         help='Disable the web dashboard; console + topic output only')
    ros_args = []
    if '--ros-args' in argv:
        idx = argv.index('--ros-args')
        ros_args = argv[idx:]
        argv = argv[:idx]
    args = parser.parse_args(argv)

    args.ground_namespaces = [n.strip() for n in args.ground_namespaces.split(',') if n.strip()]
    if args.callsigns.strip():
        args.callsigns = [c.strip() for c in args.callsigns.split(',') if c.strip()]
    else:
        args.callsigns = [f'GRND{i+1:02d}' for i in range(len(args.ground_namespaces))]
    if len(args.callsigns) != len(args.ground_namespaces):
        parser.error('--callsigns must have the same number of entries as --ground-namespaces')
    return args, ros_args


class Track:
    def __init__(self, namespace, callsign):
        self.namespace = namespace
        self.callsign = callsign
        self.x = None
        self.y = None
        self.yaw = 0.0
        self.speed = 0.0
        self.stamp = 0.0


class MultiSurveillanceStation(Node):

    def __init__(self, args):
        super().__init__('multi_surveillance_station')
        self.args = args
        self.lock = threading.Lock()

        self.tracks = [Track(ns, cs) for ns, cs in zip(args.ground_namespaces, args.callsigns)]
        self.drone_xyz = None  # (x, y, z, stamp)
        self.current_target_ns = None

        best_effort_qos = QoSProfile(depth=10, reliability=QoSReliabilityPolicy.BEST_EFFORT)

        self._subs = []
        for t in self.tracks:
            sub = self.create_subscription(
                Odometry, f'/{t.namespace}/odom',
                (lambda msg, tt=t: self.ground_odom_cb(msg, tt)), best_effort_qos)
            self._subs.append(sub)

        self.drone_odom_sub = self.create_subscription(
            Odometry, f'/{args.drone_namespace}/odom', self.drone_odom_cb, best_effort_qos)
        self.target_sub = self.create_subscription(
            String, '/surveillance/current_target', self.target_cb, 10)

        self.report_pub = self.create_publisher(String, '/surveillance/station_report', 10)
        self.timer = self.create_timer(1.0 / max(args.report_rate, 0.1), self.tick)

        self.get_logger().info(
            f'Multi-robot surveillance station online. Tracking '
            f'{[t.callsign for t in self.tracks]} via {args.drone_callsign}.')

    def ground_odom_cb(self, msg, track):
        p = msg.pose.pose.position
        yaw = yaw_from_quaternion(msg.pose.pose.orientation)
        v = msg.twist.twist.linear
        speed = math.hypot(v.x, v.y)
        with self.lock:
            track.x, track.y, track.yaw, track.speed = p.x, p.y, yaw, speed
            track.stamp = time.time()

    def drone_odom_cb(self, msg):
        p = msg.pose.pose.position
        with self.lock:
            self.drone_xyz = (p.x, p.y, p.z, time.time())

    def target_cb(self, msg):
        with self.lock:
            self.current_target_ns = msg.data

    def build_report(self):
        with self.lock:
            drone = self.drone_xyz
            target_ns = self.current_target_ns
            snapshot = [(t.namespace, t.callsign, t.x, t.y, t.yaw, t.speed, t.stamp) for t in self.tracks]

        now = time.time()
        entries = []
        # If no authoritative target announced yet, fall back to whichever
        # robot is currently closest to the drone.
        best_ns, best_range = None, None

        for ns, cs, x, y, yaw, speed, stamp in snapshot:
            rng = bearing = None
            if drone is not None and x is not None:
                dx, dy = x - drone[0], y - drone[1]
                rng = math.hypot(dx, dy)
                bearing = math.degrees(math.atan2(dy, dx)) % 360.0
                if best_range is None or rng < best_range:
                    best_range, best_ns = rng, ns

            entries.append({
                'namespace': ns,
                'callsign': cs,
                'position': [round(x, 3), round(y, 3)] if x is not None else None,
                'heading_deg': round(math.degrees(yaw) % 360.0, 1) if x is not None else None,
                'speed_mps': round(speed, 2) if x is not None else None,
                'range_m': round(rng, 2) if rng is not None else None,
                'bearing_deg': round(bearing, 1) if bearing is not None else None,
                'age_s': round(now - stamp, 1) if stamp else None,
                'status': 'NO DATA' if x is None else 'PENDING',
            })

        target_ns = target_ns or best_ns
        for e in entries:
            if e['position'] is not None:
                e['status'] = 'OVERWATCH' if e['namespace'] == target_ns else 'TRACKING'

        return {
            'timestamp': now,
            'drone_callsign': self.args.drone_callsign,
            'drone_position': [round(drone[0], 3), round(drone[1], 3), round(drone[2], 3)] if drone else None,
            'current_target': target_ns,
            'tracks': entries,
        }

    def format_console_report(self, r):
        lines = ['=========== SURVEILLANCE STATION - MULTI-CONTACT REPORT ============']
        if r['drone_position']:
            dx, dy, dz = r['drone_position']
            lines.append(f"OVERWATCH: {r['drone_callsign']:<10} ALT={dz:.1f}m  POS=({dx:.2f},{dy:.2f})")
        for e in r['tracks']:
            if e['position'] is None:
                lines.append(f"{e['callsign']:<10} NO DATA")
                continue
            x, y = e['position']
            rng = e['range_m'] if e['range_m'] is not None else float('nan')
            brg = e['bearing_deg'] if e['bearing_deg'] is not None else float('nan')
            lines.append(
                f"{e['callsign']:<10} [{e['status']:<9}] X={x:6.2f} Y={y:6.2f} "
                f"HDG={e['heading_deg']:5.1f}deg SPD={e['speed_mps']:.2f}m/s  "
                f"RNG={rng:5.2f}m BRG={brg:5.1f}deg"
            )
        lines.append('=====================================================================')
        return '\n'.join(lines)

    def tick(self):
        report = self.build_report()
        self.report_pub.publish(String(data=json.dumps(report)))
        self.get_logger().info('\n' + self.format_console_report(report))
        if WEB_STATE is not None:
            with WEB_STATE['lock']:
                WEB_STATE['report'] = report


# --- Optional Flask multi-target "radar scope" web dashboard ----------------

WEB_STATE = None

RADAR_PAGE = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Multi-Robot Surveillance Station</title>
<style>
  body { background:#04110a; color:#39ff6a; font-family:'Courier New',monospace; margin:0; display:flex; flex-wrap:wrap; }
  #scope { background:radial-gradient(circle, #062b12 0%, #02160a 80%); border-right:2px solid #39ff6a44; }
  #panel { padding:20px; min-width:420px; }
  h1 { font-size:16px; letter-spacing:2px; border-bottom:1px solid #39ff6a55; padding-bottom:8px; }
  table { border-collapse: collapse; width:100%; font-size:13px; margin-top:10px; }
  th, td { text-align:left; padding:4px 6px; border-bottom:1px solid #39ff6a22; }
  th { color:#39ff6a88; font-weight:normal; }
  .status-OVERWATCH { color:#ff4444; font-weight:bold; }
  .status-TRACKING { color:#39ff6a; }
  .status-NODATA { color:#666; }
</style>
</head>
<body>
  <canvas id="scope" width="600" height="600"></canvas>
  <div id="panel">
    <h1>&#9673; MULTI-ROBOT SURVEILLANCE STATION</h1>
    <div id="drone">OVERWATCH: --</div>
    <table>
      <thead><tr><th>CALLSIGN</th><th>STATUS</th><th>POS</th><th>HDG</th><th>SPD</th><th>RNG</th></tr></thead>
      <tbody id="rows"></tbody>
    </table>
  </div>
<script>
const cvs = document.getElementById('scope');
const ctx = cvs.getContext('2d');
const cx = 300, cy = 300, R = 280;
const SCALE = 12; // px per meter (wider than single-robot view -- 4 robots spread further out)
let sweep = 0;
let latest = null;

function drawScope(data) {
  ctx.clearRect(0,0,600,600);
  ctx.strokeStyle = '#39ff6a33';
  for (let i=1;i<=4;i++){ ctx.beginPath(); ctx.arc(cx,cy,R*i/4,0,2*Math.PI); ctx.stroke(); }
  ctx.beginPath(); ctx.moveTo(cx,0); ctx.lineTo(cx,600); ctx.moveTo(0,cy); ctx.lineTo(600,cy); ctx.stroke();

  sweep = (sweep + 2) % 360;
  const rad = sweep*Math.PI/180;
  const grad = ctx.createLinearGradient(cx,cy, cx+R*Math.cos(rad), cy+R*Math.sin(rad));
  grad.addColorStop(0,'#39ff6a55'); grad.addColorStop(1,'#39ff6a00');
  ctx.strokeStyle = grad; ctx.lineWidth = 20;
  ctx.beginPath(); ctx.moveTo(cx,cy); ctx.lineTo(cx+R*Math.cos(rad), cy+R*Math.sin(rad)); ctx.stroke();
  ctx.lineWidth = 1;

  if (!data) return;

  if (data.drone_position) {
    const [ddxp, ddyp] = data.drone_position;
    const ddx = cx + ddxp*SCALE, ddy = cy - ddyp*SCALE;
    ctx.strokeStyle = '#33ccff';
    ctx.beginPath(); ctx.moveTo(ddx-8,ddy); ctx.lineTo(ddx+8,ddy);
    ctx.moveTo(ddx,ddy-8); ctx.lineTo(ddx,ddy+8); ctx.stroke();
    ctx.fillStyle = '#33ccff';
    ctx.fillText(data.drone_callsign, ddx+10, ddy+14);

    (data.tracks || []).forEach(t => {
      if (!t.position) return;
      const [tx, ty] = t.position;
      const px = cx + tx*SCALE, py = cy - ty*SCALE;
      if (t.status === 'OVERWATCH') {
        ctx.beginPath(); ctx.moveTo(ddx,ddy); ctx.lineTo(px,py);
        ctx.strokeStyle = '#ff444455'; ctx.stroke();
      }
    });
  }

  (data.tracks || []).forEach(t => {
    if (!t.position) return;
    const [tx, ty] = t.position;
    const px = cx + tx*SCALE, py = cy - ty*SCALE;
    const isTarget = t.status === 'OVERWATCH';
    ctx.fillStyle = isTarget ? '#ff4444' : '#39ff6a';
    ctx.beginPath(); ctx.arc(px,py,isTarget?7:5,0,2*Math.PI); ctx.fill();

    // heading tick
    if (t.heading_deg != null) {
      const hr = t.heading_deg * Math.PI/180;
      ctx.strokeStyle = ctx.fillStyle;
      ctx.beginPath(); ctx.moveTo(px,py); ctx.lineTo(px+14*Math.cos(hr), py-14*Math.sin(hr)); ctx.stroke();
    }

    ctx.font = '12px monospace';
    ctx.fillText(t.callsign, px+10, py-8);
  });
}

function updatePanel(d) {
  if (!d) return;
  document.getElementById('drone').textContent = d.drone_position
    ? `OVERWATCH: ${d.drone_callsign}  alt=${d.drone_position[2]}m  pos=(${d.drone_position[0]}, ${d.drone_position[1]})`
    : 'OVERWATCH: --';
  const rows = document.getElementById('rows');
  rows.innerHTML = '';
  (d.tracks || []).forEach(t => {
    const tr = document.createElement('tr');
    const statusClass = t.status === 'NO DATA' ? 'status-NODATA' : 'status-' + t.status;
    tr.innerHTML = `<td>${t.callsign}</td>` +
      `<td class="${statusClass}">${t.status}</td>` +
      `<td>${t.position ? t.position[0]+', '+t.position[1] : '--'}</td>` +
      `<td>${t.heading_deg != null ? t.heading_deg+'deg' : '--'}</td>` +
      `<td>${t.speed_mps != null ? t.speed_mps+'m/s' : '--'}</td>` +
      `<td>${t.range_m != null ? t.range_m+'m' : '--'}</td>`;
    rows.appendChild(tr);
  });
}

async function poll() {
  try {
    const res = await fetch('/api/report');
    latest = await res.json();
    updatePanel(latest);
  } catch(e) {}
}
setInterval(poll, 500);
poll();

function loop() { drawScope(latest); requestAnimationFrame(loop); }
loop();
</script>
</body>
</html>
"""


def start_web_server(port):
    from flask import Flask, jsonify

    app = Flask(__name__)

    @app.route('/')
    def index():
        return RADAR_PAGE

    @app.route('/api/report')
    def api_report():
        with WEB_STATE['lock']:
            return jsonify(WEB_STATE['report'])

    def run():
        app.run(host='0.0.0.0', port=port, debug=False, use_reloader=False)

    thread = threading.Thread(target=run, daemon=True)
    thread.start()


def main():
    args, ros_args = parse_args(sys.argv[1:])

    global WEB_STATE
    if not args.no_web:
        WEB_STATE = {'lock': threading.Lock(), 'report': None}
        try:
            start_web_server(args.web_port)
            print(f'[multi_surveillance_station] radar scope live at http://0.0.0.0:{args.web_port}/')
        except ImportError:
            print('[multi_surveillance_station] Flask not installed, web dashboard disabled '
                  '(pip3 install flask --break-system-packages). Continuing console/topic-only.')
            WEB_STATE = None

    rclpy.init(args=ros_args)
    node = MultiSurveillanceStation(args)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
