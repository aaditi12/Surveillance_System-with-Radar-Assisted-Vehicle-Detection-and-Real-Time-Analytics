#!/usr/bin/env python3
"""
ground_auto_patrol.py

Fully autonomous patrol for the ground robot -- no waypoints given on the
CLI. It listens to the live occupancy grid (/<namespace>/map, published by
map_server) and, forever:
  1. samples a random free-space cell (with a safety margin so goals
     aren't picked right up against a wall),
  2. sends it to Nav2 as a NavigateToPose goal (full costmap-aware
     planning + DWB control + recovery behaviors, same stack as
     ground_nav_patrol.py),
  3. waits for success/failure, then picks a new random goal and repeats.

This is what makes the ground robot move on its own: nothing to type
after startup, it just keeps roaming the map.

Requires, in separate terminals (or via a bringup launch file), in order:
    1. ros2 launch testbed_gazebo spawn_playground.launch.py
    2. ros2 launch testbed_gazebo spawn_ground_robot.launch.py
    3. ros2 launch testbed_navigation localization.launch.py
    4. ros2 launch testbed_navigation navigation.launch.py

Usage:
    # roam forever, using the robot's spawn pose as AMCL's initial pose
    ros2 run testbed_navigation ground_auto_patrol.py --initial-pose 0 5 0

    # already localized (set 2D Pose Estimate in RViz) -- just start roaming
    ros2 run testbed_navigation ground_auto_patrol.py

    # tune margin / min goal distance / reproducibility
    ros2 run testbed_navigation ground_auto_patrol.py --margin-cells 4 --min-goal-distance 1.5 --seed 42

Notes:
    - Uses nav2_simple_commander's BasicNavigator, namespaced to match
      navigation.launch.py / localization.launch.py's robot_name (default
      "ground_robot").
    - "Free" cells require an NxN neighborhood (--margin-cells) to also be
      free/known, so goals aren't dropped flush against walls/clutter --
      a cheap stand-in for checking the inflated costmap.
    - The leading "--" isn't needed here (no positional coords), but any
      trailing ROS args still work normally.
"""

import argparse
import math
import random
import sys

import rclpy
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
from nav_msgs.msg import OccupancyGrid
from rclpy.qos import QoSDurabilityPolicy, QoSProfile, QoSReliabilityPolicy


def parse_args(argv):
    parser = argparse.ArgumentParser(
        description='Autonomous random-goal Nav2 patrol for the ground robot (no waypoints needed).')
    parser.add_argument('--namespace', default='ground_robot',
                         help='Robot namespace, must match navigation.launch.py robot_name (default: ground_robot)')
    parser.add_argument('--initial-pose', nargs=3, type=float, metavar=('X', 'Y', 'YAW_DEG'), default=None,
                         help='Set AMCL initial pose before roaming, instead of using RViz "2D Pose Estimate"')
    parser.add_argument('--margin-cells', type=int, default=4,
                         help='Free-space safety margin around a candidate goal cell, in map cells (default: 4)')
    parser.add_argument('--min-goal-distance', type=float, default=1.0,
                         help='Minimum distance a new goal must be from the robot''s last goal, m (default: 1.0)')
    parser.add_argument('--max-sample-attempts', type=int, default=500,
                         help='Random samples to try before giving up on picking a goal (default: 500)')
    parser.add_argument('--seed', type=int, default=None,
                         help='Random seed, for reproducible routes (default: unseeded)')
    return parser.parse_args(argv)


class MapSampler:
    """Grabs one latched OccupancyGrid and offers random free-space points from it."""

    def __init__(self, node, namespace):
        self.node = node
        self.grid = None
        map_qos = QoSProfile(
            depth=1,
            reliability=QoSReliabilityPolicy.RELIABLE,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
        )
        self.sub = node.create_subscription(
            OccupancyGrid, f'/{namespace}/map', self._map_cb, map_qos)

    def _map_cb(self, msg):
        self.grid = msg

    def wait_for_map(self, timeout_sec=30.0):
        elapsed = 0.0
        while self.grid is None and elapsed < timeout_sec:
            rclpy.spin_once(self.node, timeout_sec=0.5)
            elapsed += 0.5
        return self.grid is not None

    def _is_free(self, gx, gy, margin):
        info = self.grid.info
        data = self.grid.data
        w, h = info.width, info.height
        for dy in range(-margin, margin + 1):
            for dx in range(-margin, margin + 1):
                nx, ny = gx + dx, gy + dy
                if nx < 0 or ny < 0 or nx >= w or ny >= h:
                    return False
                v = data[ny * w + nx]
                if v < 0 or v >= 50:  # unknown or occupied (occupied_thresh ~0.65 -> ~65, but be conservative)
                    return False
        return True

    def random_free_point(self, margin, max_attempts):
        info = self.grid.info
        w, h = info.width, info.height
        res = info.resolution
        ox, oy = info.origin.position.x, info.origin.position.y

        for _ in range(max_attempts):
            gx = random.randrange(w)
            gy = random.randrange(h)
            if self._is_free(gx, gy, margin):
                wx = ox + (gx + 0.5) * res
                wy = oy + (gy + 0.5) * res
                return wx, wy
        return None


def make_pose(navigator, x, y, yaw_deg=0.0):
    yaw = math.radians(yaw_deg)
    pose = PoseStamped()
    pose.header.frame_id = 'map'
    pose.header.stamp = navigator.get_clock().now().to_msg()
    pose.pose.position.x = x
    pose.pose.position.y = y
    pose.pose.orientation.z = math.sin(yaw / 2.0)
    pose.pose.orientation.w = math.cos(yaw / 2.0)
    return pose


def main():
    raw = rclpy.utilities.remove_ros_args(sys.argv)[1:]
    args = parse_args(raw)
    if args.seed is not None:
        random.seed(args.seed)

    rclpy.init()
    navigator = BasicNavigator(namespace=f'/{args.namespace}')

    if args.initial_pose is not None:
        x, y, yaw_deg = args.initial_pose
        navigator.setInitialPose(make_pose(navigator, x, y, yaw_deg))

    navigator.info('Waiting for Nav2 to become active...')
    navigator.waitUntilNav2Active(localizer='amcl')

    sampler = MapSampler(navigator, args.namespace)
    navigator.info('Waiting for /%s/map...' % args.namespace)
    if not sampler.wait_for_map():
        navigator.error('Timed out waiting for the map -- is map_server running and latched?')
        rclpy.shutdown()
        return

    last_x, last_y = None, None
    goal_count = 0

    try:
        while rclpy.ok():
            point = None
            for _ in range(5):  # a few outer retries in case min-distance keeps rejecting samples
                candidate = sampler.random_free_point(args.margin_cells, args.max_sample_attempts)
                if candidate is None:
                    break
                cx, cy = candidate
                if last_x is None or math.hypot(cx - last_x, cy - last_y) >= args.min_goal_distance:
                    point = candidate
                    break

            if point is None:
                navigator.error('Could not sample a valid free-space goal -- retrying in a moment.')
                rclpy.spin_once(navigator, timeout_sec=1.0)
                continue

            goal_count += 1
            gx, gy = point
            yaw_deg = math.degrees(math.atan2(gy - (last_y or gy), gx - (last_x or gx)))
            navigator.info(f'--- Autonomous goal {goal_count}: ({gx:.2f}, {gy:.2f}) ---')
            navigator.goToPose(make_pose(navigator, gx, gy, yaw_deg))

            while not navigator.isTaskComplete():
                feedback = navigator.getFeedback()
                if feedback and int(feedback.navigation_time.sec) % 5 == 0:
                    navigator.info(f'  remaining distance: {feedback.distance_remaining:.2f} m')

            result = navigator.getResult()
            if result == TaskResult.SUCCEEDED:
                navigator.info(f'Goal {goal_count} reached.')
                last_x, last_y = gx, gy
            elif result == TaskResult.CANCELED:
                navigator.info(f'Goal {goal_count} canceled.')
                break
            else:
                navigator.error(f'Goal {goal_count} failed -- picking a new goal.')
                # don't update last_x/last_y so the next sample isn't biased toward the failed spot

    except KeyboardInterrupt:
        navigator.cancelTask()

    navigator.info('Autonomous patrol stopped.')
    navigator.lifecycleShutdown()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
