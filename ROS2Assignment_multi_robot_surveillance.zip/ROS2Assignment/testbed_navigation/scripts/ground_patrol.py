#!/usr/bin/env python3
"""
ground_patrol.py

Scripted waypoint / patrol control for the ground differential-drive
robot, driven entirely from the CLI (no keyboard needed).

Unlike the drone (holonomic planar_move), the ground robot is a real
diff-drive: only linear.x (forward) and angular.z (turn) are usable, so
this closes a heading-then-drive P-controller loop on
<namespace>/odom -> <namespace>/cmd_vel:
  - turn to face the next waypoint (angular P on heading error)
  - drive forward, throttled down while heading error is large so it
    turns in place first rather than arcing wide

If a waypoint sits close to directly behind the robot, tiny odometry
noise can flip atan2(ey, ex) back and forth between values near +pi and
-pi every tick, making the commanded angular.z flip sign each cycle --
the robot just chatters in place instead of completing the turn ("only
spinning, not moving"). To prevent that, the target direction is
low-pass filtered on the (ex, ey) vector itself (not on the angle, which
would have its own wraparound problem), and the angular command is
rate-limited so a residual flip can't produce a sudden reversal.

Usage examples:
    # one-shot list of waypoints (x y pairs), visited in order
    ros2 run testbed_navigation ground_patrol.py -- 0.0 5.0  3.0 5.0  3.0 -3.0  0.0 -3.0

    # loop the same route forever
    ros2 run testbed_navigation ground_patrol.py -- 0.0 5.0  3.0 5.0 --loop

    # tune speed / arrival tolerance / per-waypoint hold time
    ros2 run testbed_navigation ground_patrol.py -- 0 0  5 0 --speed 0.4 --tolerance 0.15 --hold 2.0

    # different ground robot namespace (must match robot_name used at spawn)
    ros2 run testbed_navigation ground_patrol.py -- 0 0  5 0 --namespace my_robot

Notes:
    - Requires the ground robot already spawned, e.g.:
        ros2 launch testbed_gazebo spawn_ground_robot.launch.py
    - The leading "--" separates this script's own args from ROS args,
      standard argparse/ros2 convention -- keep it.
    - Logs position/yaw/heading-error/command once a second so you can see
      it converging (or not) instead of guessing from the outside.
"""

import argparse
import math
import sys
import time

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy


def parse_args(argv):
    parser = argparse.ArgumentParser(description='Scripted waypoint patrol for the ground robot.')
    parser.add_argument('coords', nargs='+', type=float,
                         help='Flat list of waypoints as x1 y1 x2 y2 ... (even count required)')
    parser.add_argument('--namespace', default='ground_robot',
                         help='Ground robot namespace / robot_name used at spawn (default: ground_robot)')
    parser.add_argument('--speed', type=float, default=0.4,
                         help='Max forward speed, m/s (default: 0.4)')
    parser.add_argument('--angular-speed', type=float, default=1.0,
                         help='Max turn rate, rad/s (default: 1.0)')
    parser.add_argument('--tolerance', type=float, default=0.2,
                         help='Arrival radius, m (default: 0.2)')
    parser.add_argument('--hold', type=float, default=0.0,
                         help='Seconds to pause at each waypoint before moving on (default: 0.0)')
    parser.add_argument('--loop', action='store_true',
                         help='Repeat the waypoint route forever instead of stopping at the end')
    parser.add_argument('--kp-lin', type=float, default=0.8,
                         help='Proportional gain on distance error (default: 0.8)')
    parser.add_argument('--kp-ang', type=float, default=1.5,
                         help='Proportional gain on heading error (default: 1.5)')
    parser.add_argument('--max-angular-accel', type=float, default=3.0,
                         help='Max change in angular.z per second, rad/s^2 (default: 3.0) '
                              '-- rate-limits the command to stop sign-flip chatter')
    args = parser.parse_args(argv)

    if len(args.coords) % 2 != 0:
        parser.error('coords must be given in x y pairs (even count)')

    args.waypoints = list(zip(args.coords[0::2], args.coords[1::2]))
    return args


def yaw_from_quaternion(q):
    # standard yaw extraction from a geometry_msgs/Quaternion
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def normalize_angle(angle):
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


class GroundPatrol(Node):

    DT = 0.1  # control timer period, s
    FILTER_ALPHA = 0.3  # low-pass gain on the (ex, ey) direction vector

    def __init__(self, args):
        super().__init__('ground_patrol')
        self.args = args
        self.waypoints = args.waypoints
        self.wp_index = 0
        self.hold_until = None

        self.x = None
        self.y = None
        self.yaw = None

        self.filt_ex = None
        self.filt_ey = None
        self.prev_angular_z = 0.0
        self.last_log = 0.0

        best_effort_qos = QoSProfile(depth=10, reliability=QoSReliabilityPolicy.BEST_EFFORT)

        self.cmd_pub = self.create_publisher(Twist, f'/{args.namespace}/cmd_vel', 10)
        self.odom_sub = self.create_subscription(
            Odometry, f'/{args.namespace}/odom', self.odom_cb, best_effort_qos)

        self.get_logger().info(
            f'Patrolling {len(self.waypoints)} waypoint(s) on /{args.namespace}, '
            f'loop={args.loop}, speed<= {args.speed} m/s, tol={args.tolerance} m'
        )

        self.timer = self.create_timer(self.DT, self.control_loop)

    def odom_cb(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        self.yaw = yaw_from_quaternion(msg.pose.pose.orientation)

    def stop(self):
        self.cmd_pub.publish(Twist())

    def control_loop(self):
        if self.x is None:
            return  # no odom yet

        if self.wp_index >= len(self.waypoints):
            if self.args.loop:
                self.wp_index = 0
                self.filt_ex = self.filt_ey = None  # fresh filter state for the new leg
            else:
                self.stop()
                self.get_logger().info('Patrol route complete.')
                self.timer.cancel()
                return

        tx, ty = self.waypoints[self.wp_index]
        ex, ey = tx - self.x, ty - self.y
        dist = math.hypot(ex, ey)

        if dist <= self.args.tolerance:
            self.stop()
            now = time.monotonic()
            if self.hold_until is None:
                self.hold_until = now + self.args.hold
                self.get_logger().info(
                    f'Reached waypoint {self.wp_index + 1}/{len(self.waypoints)} '
                    f'({tx:.2f}, {ty:.2f})'
                    + (f', holding {self.args.hold:.1f}s' if self.args.hold > 0 else '')
                )
            if now >= self.hold_until:
                self.hold_until = None
                self.wp_index += 1
                self.filt_ex = self.filt_ey = None  # fresh filter state for the next leg
            return

        # Low-pass filter the direction vector itself (not the angle -- an
        # angle filter has its own wraparound problem right where this bug
        # bites hardest, near +/-pi) so single-sample odometry noise can't
        # flip which side of the robot the target appears to be on.
        if self.filt_ex is None:
            self.filt_ex, self.filt_ey = ex, ey
        else:
            a = self.FILTER_ALPHA
            self.filt_ex = a * ex + (1 - a) * self.filt_ex
            self.filt_ey = a * ey + (1 - a) * self.filt_ey

        heading_error = normalize_angle(math.atan2(self.filt_ey, self.filt_ex) - self.yaw)

        desired_angular_z = max(-self.args.angular_speed,
                                 min(self.args.angular_speed, self.args.kp_ang * heading_error))

        # Rate-limit so any residual flip can't show up as a sudden reversal.
        max_step = self.args.max_angular_accel * self.DT
        angular_z = max(self.prev_angular_z - max_step,
                         min(self.prev_angular_z + max_step, desired_angular_z))
        self.prev_angular_z = angular_z

        # throttle forward speed down as heading error grows, so it turns
        # in place first instead of arcing wide (diff drive can't strafe)
        throttle = max(0.0, math.cos(heading_error))
        linear_x = max(0.0, min(self.args.speed, self.args.kp_lin * dist)) * throttle

        cmd = Twist()
        cmd.linear.x = linear_x
        cmd.angular.z = angular_z
        self.cmd_pub.publish(cmd)

        now = time.monotonic()
        if now - self.last_log >= 1.0:
            self.last_log = now
            self.get_logger().info(
                f'wp {self.wp_index + 1}/{len(self.waypoints)} '
                f'pos=({self.x:.2f},{self.y:.2f}) yaw={math.degrees(self.yaw):.0f}deg '
                f'dist={dist:.2f}m heading_err={math.degrees(heading_error):.0f}deg '
                f'cmd(v={linear_x:.2f},w={angular_z:.2f})'
            )


def main(args=None):
    # Split off ROS-specific args (after --ros-args) before argparse sees argv.
    raw = rclpy.utilities.remove_ros_args(sys.argv)[1:]
    parsed = parse_args(raw)

    rclpy.init(args=args)
    node = GroundPatrol(parsed)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
