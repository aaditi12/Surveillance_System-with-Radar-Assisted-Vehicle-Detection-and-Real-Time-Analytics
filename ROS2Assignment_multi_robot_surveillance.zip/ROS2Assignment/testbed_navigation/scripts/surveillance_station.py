#!/usr/bin/env python3
"""
surveillance_station.py

Ground control / "control tower" node for the drone-vs-ground-robot
surveillance demo. Consumes the drone's ArUco-based visual track of the
ground robot (published by aruco_ground_tracker.py) together with both
robots' odometry, and turns it into:

  1. A periodic, human-readable ATC-style contact report on the console,
     e.g.:

        =========== SURVEILLANCE STATION - CONTACT REPORT ============
        TRACK    : GROUND-ROBOT (callsign GRND01)   STATUS: TRACKING
        POSITION : X= 2.31  Y=-1.04  HDG=142deg  SPD=0.28 m/s
        OVERWATCH: DRONE01  ALT=6.0m  RNG=0.34m  BRG=142deg
        CONTACT  : visual (ArUco)     AGE: 0.1s
        =================================================================

     Falls back to "COASTING" (last known position, aged) when the visual
     marker drops out of view, the same way an ATC radar coasts a track
     that's briefly lost, instead of just going silent.

  2. A machine-readable /surveillance/station_report (std_msgs/String,
     JSON) topic so any other tool can consume the same consolidated
     picture without re-deriving range/bearing itself.

  3. An optional live web "radar scope" (Flask), styled like an airport
     surveillance display: a rotating sweep, a blip + trail for the
     ground robot, and a data block (callsign / speed / heading / range)
     next to it. Open http://<host>:<port>/ once the node is running.
     Disable with --no-web if you just want the console/topic output.

Usage:
    ros2 run testbed_navigation surveillance_station.py
    ros2 run testbed_navigation surveillance_station.py \\
        --ground-namespace ground_robot --drone-namespace drone \\
        --web-port 8080 --report-rate 1.0

    # console/topic only, no web server
    ros2 run testbed_navigation surveillance_station.py --no-web
"""

import argparse
import json
import math
import sys
import threading
import time
from collections import deque

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy

from std_msgs.msg import String, Bool
from geometry_msgs.msg import PointStamped
from nav_msgs.msg import Odometry


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def parse_args(argv):
    parser = argparse.ArgumentParser(
        description='ATC-style surveillance station: consolidated drone/ground-robot contact reports + radar-scope web view.')
    parser.add_argument('--ground-namespace', default='ground_robot',
                         help='Namespace of the tracked ground robot (default: ground_robot)')
    parser.add_argument('--drone-namespace', default='drone',
                         help='Namespace of the overwatch drone (default: drone)')
    parser.add_argument('--ground-callsign', default='GRND01',
                         help='Display callsign for the ground robot track (default: GRND01)')
    parser.add_argument('--drone-callsign', default='DRONE01',
                         help='Display callsign for the drone (default: DRONE01)')
    parser.add_argument('--report-rate', type=float, default=1.0,
                         help='Console contact-report rate in Hz (default: 1.0)')
    parser.add_argument('--coast-timeout', type=float, default=3.0,
                         help='Seconds without a visible marker before a track is reported LOST rather than COASTING (default: 3.0)')
    parser.add_argument('--web-port', type=int, default=8080,
                         help='Port for the radar-scope web dashboard (default: 8080)')
    parser.add_argument('--no-web', action='store_true',
                         help='Disable the web dashboard; console + topic output only')
    ros_args = []
    if '--ros-args' in argv:
        idx = argv.index('--ros-args')
        ros_args = argv[idx:]
        argv = argv[:idx]
    return parser.parse_args(argv), ros_args


class SurveillanceStation(Node):

    def __init__(self, args):
        super().__init__('surveillance_station')
        self.args = args

        best_effort_qos = QoSProfile(depth=10, reliability=QoSReliabilityPolicy.BEST_EFFORT)

        # Live state, guarded by self.lock since the Flask thread reads it too.
        self.lock = threading.Lock()
        self.ground_odom = None          # (x, y, yaw, speed, stamp)
        self.drone_odom = None           # (x, y, z, stamp)
        self.marker_pos = None           # (x, y, stamp) -- visual track of ground robot
        self.marker_visible = False
        self.last_visible_stamp = 0.0
        self.trail = deque(maxlen=200)   # recent (x, y) for the radar-scope trail

        self.ground_odom_sub = self.create_subscription(
            Odometry, f'/{args.ground_namespace}/odom', self.ground_odom_cb, best_effort_qos)
        self.drone_odom_sub = self.create_subscription(
            Odometry, f'/{args.drone_namespace}/odom', self.drone_odom_cb, best_effort_qos)
        self.aruco_pos_sub = self.create_subscription(
            PointStamped, f'/{args.drone_namespace}/aruco/ground_robot_position',
            self.aruco_pos_cb, best_effort_qos)
        self.aruco_visible_sub = self.create_subscription(
            Bool, f'/{args.drone_namespace}/aruco/marker_visible',
            self.aruco_visible_cb, best_effort_qos)

        self.report_pub = self.create_publisher(String, '/surveillance/station_report', 10)

        self.timer = self.create_timer(1.0 / max(args.report_rate, 0.1), self.tick)

        self.get_logger().info(
            f'Surveillance station online. Tracking {args.ground_callsign} '
            f'(ns={args.ground_namespace}) via {args.drone_callsign} (ns={args.drone_namespace}).')

    def ground_odom_cb(self, msg):
        p = msg.pose.pose.position
        yaw = yaw_from_quaternion(msg.pose.pose.orientation)
        v = msg.twist.twist.linear
        speed = math.hypot(v.x, v.y)
        with self.lock:
            self.ground_odom = (p.x, p.y, yaw, speed, time.time())

    def drone_odom_cb(self, msg):
        p = msg.pose.pose.position
        with self.lock:
            self.drone_odom = (p.x, p.y, p.z, time.time())

    def aruco_pos_cb(self, msg):
        with self.lock:
            self.marker_pos = (msg.point.x, msg.point.y, time.time())
            self.trail.append((msg.point.x, msg.point.y))

    def aruco_visible_cb(self, msg):
        with self.lock:
            self.marker_visible = bool(msg.data)
            if self.marker_visible:
                self.last_visible_stamp = time.time()

    def build_report(self):
        """Assemble a consolidated report dict from current state. Returns None if no data yet."""
        with self.lock:
            ground = self.ground_odom
            drone = self.drone_odom
            marker = self.marker_pos
            visible = self.marker_visible
            last_visible = self.last_visible_stamp
            trail = list(self.trail)

        now = time.time()

        if ground is None and marker is None:
            return None

        # Prefer the visual (ArUco) track like a real radar contact; fall back
        # to raw odom only if the tracker has never reported anything yet.
        if marker is not None:
            gx, gy, _ = marker
        elif ground is not None:
            gx, gy = ground[0], ground[1]
        else:
            gx = gy = None

        age = (now - last_visible) if last_visible else None
        if visible:
            contact_status = 'TRACKING'
        elif age is not None and age < self.args.coast_timeout:
            contact_status = 'COASTING'
        else:
            contact_status = 'LOST'

        heading_deg = math.degrees(ground[2]) % 360.0 if ground else None
        speed = ground[3] if ground else None

        rng = bearing = None
        if drone is not None and gx is not None:
            dx = gx - drone[0]
            dy = gy - drone[1]
            rng = math.hypot(dx, dy)
            bearing = math.degrees(math.atan2(dy, dx)) % 360.0

        report = {
            'timestamp': now,
            'ground_callsign': self.args.ground_callsign,
            'drone_callsign': self.args.drone_callsign,
            'status': contact_status,
            'ground_position': [round(gx, 3), round(gy, 3)] if gx is not None else None,
            'ground_heading_deg': round(heading_deg, 1) if heading_deg is not None else None,
            'ground_speed_mps': round(speed, 2) if speed is not None else None,
            'drone_position': [round(drone[0], 3), round(drone[1], 3), round(drone[2], 3)] if drone else None,
            'range_m': round(rng, 2) if rng is not None else None,
            'bearing_deg': round(bearing, 1) if bearing is not None else None,
            'contact_age_s': round(age, 1) if age is not None else None,
            'contact_method': 'visual (ArUco)' if marker is not None else 'odometry',
            'trail': trail[-50:],
        }
        return report

    def format_console_report(self, r):
        lines = []
        lines.append('=========== SURVEILLANCE STATION - CONTACT REPORT ============')
        lines.append(f"TRACK    : {r['ground_callsign']:<20} STATUS: {r['status']}")
        if r['ground_position']:
            x, y = r['ground_position']
            hdg = r['ground_heading_deg'] if r['ground_heading_deg'] is not None else float('nan')
            spd = r['ground_speed_mps'] if r['ground_speed_mps'] is not None else float('nan')
            lines.append(f"POSITION : X={x:6.2f}  Y={y:6.2f}  HDG={hdg:5.1f}deg  SPD={spd:.2f} m/s")
        else:
            lines.append('POSITION : NO DATA')
        if r['drone_position']:
            dx, dy, dz = r['drone_position']
            rng = r['range_m'] if r['range_m'] is not None else float('nan')
            brg = r['bearing_deg'] if r['bearing_deg'] is not None else float('nan')
            lines.append(f"OVERWATCH: {r['drone_callsign']:<10} ALT={dz:.1f}m  RNG={rng:.2f}m  BRG={brg:5.1f}deg")
        age = r['contact_age_s'] if r['contact_age_s'] is not None else float('nan')
        lines.append(f"CONTACT  : {r['contact_method']:<15} AGE: {age:.1f}s")
        lines.append('=================================================================')
        return '\n'.join(lines)

    def tick(self):
        report = self.build_report()
        if report is None:
            return
        self.report_pub.publish(String(data=json.dumps(report)))
        self.get_logger().info('\n' + self.format_console_report(report))
        if WEB_STATE is not None:
            with WEB_STATE['lock']:
                WEB_STATE['report'] = report


# --- Optional Flask "radar scope" web dashboard -----------------------------

WEB_STATE = None

RADAR_PAGE = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Surveillance Station</title>
<style>
  body { background:#04110a; color:#39ff6a; font-family:'Courier New',monospace; margin:0; display:flex; }
  #scope { background:radial-gradient(circle, #062b12 0%, #02160a 80%); border-right:2px solid #39ff6a44; }
  #panel { padding:20px; width:360px; }
  h1 { font-size:16px; letter-spacing:2px; border-bottom:1px solid #39ff6a55; padding-bottom:8px; }
  .row { margin:10px 0; font-size:14px; }
  .label { color:#39ff6a88; display:inline-block; width:110px; }
  .val { font-weight:bold; }
  .status-TRACKING { color:#39ff6a; }
  .status-COASTING { color:#ffcc33; }
  .status-LOST { color:#ff4444; }
  .status-nodata { color:#666; }
</style>
</head>
<body>
  <canvas id="scope" width="600" height="600"></canvas>
  <div id="panel">
    <h1>&#9673; SURVEILLANCE STATION</h1>
    <div class="row"><span class="label">TRACK</span><span class="val" id="callsign">--</span></div>
    <div class="row"><span class="label">STATUS</span><span class="val" id="status">NO DATA</span></div>
    <div class="row"><span class="label">POSITION</span><span class="val" id="pos">--</span></div>
    <div class="row"><span class="label">HEADING</span><span class="val" id="hdg">--</span></div>
    <div class="row"><span class="label">SPEED</span><span class="val" id="spd">--</span></div>
    <div class="row"><span class="label">OVERWATCH</span><span class="val" id="drone">--</span></div>
    <div class="row"><span class="label">RANGE</span><span class="val" id="rng">--</span></div>
    <div class="row"><span class="label">BEARING</span><span class="val" id="brg">--</span></div>
    <div class="row"><span class="label">CONTACT AGE</span><span class="val" id="age">--</span></div>
  </div>
<script>
const cvs = document.getElementById('scope');
const ctx = cvs.getContext('2d');
const cx = 300, cy = 300, R = 280;
const SCALE = 25; // px per meter
let sweep = 0;

function drawScope(data) {
  ctx.clearRect(0,0,600,600);
  // rings
  ctx.strokeStyle = '#39ff6a33';
  for (let i=1;i<=4;i++){ ctx.beginPath(); ctx.arc(cx,cy,R*i/4,0,2*Math.PI); ctx.stroke(); }
  ctx.beginPath(); ctx.moveTo(cx,0); ctx.lineTo(cx,600); ctx.moveTo(0,cy); ctx.lineTo(600,cy); ctx.stroke();

  // sweep
  sweep = (sweep + 2) % 360;
  const rad = sweep*Math.PI/180;
  const grad = ctx.createLinearGradient(cx,cy, cx+R*Math.cos(rad), cy+R*Math.sin(rad));
  grad.addColorStop(0,'#39ff6a55'); grad.addColorStop(1,'#39ff6a00');
  ctx.strokeStyle = grad; ctx.lineWidth = 20;
  ctx.beginPath(); ctx.moveTo(cx,cy); ctx.lineTo(cx+R*Math.cos(rad), cy+R*Math.sin(rad)); ctx.stroke();
  ctx.lineWidth = 1;

  if (!data || !data.ground_position) return;

  // trail
  if (data.trail && data.trail.length) {
    ctx.strokeStyle = '#39ff6a66';
    ctx.beginPath();
    data.trail.forEach((p,i)=>{
      const px = cx + p[0]*SCALE, py = cy - p[1]*SCALE;
      if (i===0) ctx.moveTo(px,py); else ctx.lineTo(px,py);
    });
    ctx.stroke();
  }

  // ground robot blip
  const [gx, gy] = data.ground_position;
  const px = cx + gx*SCALE, py = cy - gy*SCALE;
  ctx.fillStyle = data.status === 'TRACKING' ? '#39ff6a' : (data.status === 'COASTING' ? '#ffcc33' : '#ff4444');
  ctx.beginPath(); ctx.arc(px,py,6,0,2*Math.PI); ctx.fill();
  ctx.font = '12px monospace';
  ctx.fillText(data.ground_callsign + '  ' + (data.ground_speed_mps ?? '--') + 'm/s', px+10, py-8);

  // drone
  if (data.drone_position) {
    const [dxp, dyp] = data.drone_position;
    const ddx = cx + dxp*SCALE, ddy = cy - dyp*SCALE;
    ctx.strokeStyle = '#33ccff';
    ctx.beginPath(); ctx.moveTo(ddx-8,ddy); ctx.lineTo(ddx+8,ddy);
    ctx.moveTo(ddx,ddy-8); ctx.lineTo(ddx,ddy+8); ctx.stroke();
    ctx.fillStyle = '#33ccff';
    ctx.fillText(data.drone_callsign, ddx+10, ddy+14);
    ctx.beginPath(); ctx.moveTo(ddx,ddy); ctx.lineTo(px,py);
    ctx.strokeStyle = '#33ccff44'; ctx.stroke();
  }
}

function updatePanel(d) {
  const set = (id,v)=>document.getElementById(id).textContent = v;
  if (!d) { set('status','NO DATA'); return; }
  set('callsign', d.ground_callsign);
  const st = document.getElementById('status');
  st.textContent = d.status;
  st.className = 'val status-' + d.status;
  set('pos', d.ground_position ? `X=${d.ground_position[0]}  Y=${d.ground_position[1]}` : '--');
  set('hdg', d.ground_heading_deg != null ? d.ground_heading_deg + ' deg' : '--');
  set('spd', d.ground_speed_mps != null ? d.ground_speed_mps + ' m/s' : '--');
  set('drone', d.drone_position ? `${d.drone_callsign}  alt=${d.drone_position[2]}m` : '--');
  set('rng', d.range_m != null ? d.range_m + ' m' : '--');
  set('brg', d.bearing_deg != null ? d.bearing_deg + ' deg' : '--');
  set('age', d.contact_age_s != null ? d.contact_age_s + ' s' : '--');
}

let latest = null;
async function poll() {
  try {
    const res = await fetch('/api/report');
    latest = await res.json();
    updatePanel(latest);
  } catch(e) {}
}
setInterval(poll, 500);
poll();

function loop() { drawScope(latest); requestAnimationFrame(loop); }
loop();
</script>
</body>
</html>
"""


def start_web_server(port):
    from flask import Flask, jsonify

    app = Flask(__name__)

    @app.route('/')
    def index():
        return RADAR_PAGE

    @app.route('/api/report')
    def api_report():
        with WEB_STATE['lock']:
            return jsonify(WEB_STATE['report'])

    def run():
        app.run(host='0.0.0.0', port=port, debug=False, use_reloader=False)

    thread = threading.Thread(target=run, daemon=True)
    thread.start()


def main():
    args, ros_args = parse_args(sys.argv[1:])

    global WEB_STATE
    if not args.no_web:
        WEB_STATE = {'lock': threading.Lock(), 'report': None}
        try:
            start_web_server(args.web_port)
            print(f'[surveillance_station] radar scope live at http://0.0.0.0:{args.web_port}/')
        except ImportError:
            print('[surveillance_station] Flask not installed, web dashboard disabled '
                  '(pip3 install flask --break-system-packages). Continuing console/topic-only.')
            WEB_STATE = None

    rclpy.init(args=ros_args)
    node = SurveillanceStation(args)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
