#!/usr/bin/env python3
"""
drone_patrol.py

Scripted "takeoff, then patrol" control for the surveillance drone,
driven entirely from the CLI (no keyboard needed).

Two phases:
  1. TAKEOFF - the drone's planar_move plugin only drives x/y/yaw (no
     thrust dynamics are modelled), so climbing/descending to the patrol
     altitude is done kinematically: this node calls Gazebo's
     /gazebo/set_entity_state service to ramp the model's z up (or down)
     at --climb-rate m/s while holding x/y fixed. Gravity is disabled on
     the drone body (see drone.xacro) so once set, altitude holds with no
     further service calls needed.
  2. PATROL - same P-controller loop as before, closing on
     <namespace>/odom -> waypoint error and publishing <namespace>/cmd_vel
     for x/y, at the altitude just reached.

Usage examples:
    # take off to 6m, then patrol a route, looping forever
    ros2 run testbed_navigation drone_patrol.py -- -2.0 5.0  3.0 5.0  3.0 -3.0  -2.0 -3.0 --altitude 6.0 --loop

    # just climb/descend to a new altitude, no lateral route (repeat the current spot)
    ros2 run testbed_navigation drone_patrol.py -- 0 0 --altitude 8.0

    # tune speed / arrival tolerance / per-waypoint hold time / climb rate
    ros2 run testbed_navigation drone_patrol.py -- 0 0  5 0 --speed 1.5 --tolerance 0.15 --hold 2.0 --climb-rate 0.75

    # different drone namespace / different spawn altitude (must match spawn_drone.launch.py args)
    ros2 run testbed_navigation drone_patrol.py -- 0 0  5 0 --namespace my_drone --spawn-altitude 3.0

Notes:
    - Requires the drone already spawned, e.g.:
        ros2 launch testbed_gazebo spawn_drone.launch.py
    - Requires /gazebo/set_entity_state, provided by the gazebo_ros_state
      world plugin (already added to testbed_playground.world).
    - The leading "--" separates this script's own args from ROS args,
      standard argparse/ros2 convention -- keep it.
"""

import argparse
import sys
import time

import rclpy
from gazebo_msgs.msg import EntityState
from gazebo_msgs.srv import SetEntityState
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy


def parse_args(argv):
    parser = argparse.ArgumentParser(description='Scripted takeoff + waypoint patrol for the drone.')
    parser.add_argument('coords', nargs='+', type=float,
                         help='Flat list of waypoints as x1 y1 x2 y2 ... (even count required)')
    parser.add_argument('--namespace', default='drone',
                         help='Drone namespace / robot_name used at spawn (default: drone)')
    parser.add_argument('--altitude', type=float, default=None,
                         help='Target patrol altitude, m. Default: no climb, stay at --spawn-altitude')
    parser.add_argument('--spawn-altitude', type=float, default=3.0,
                         help='Altitude the drone was spawned at (spawn_drone.launch.py "z" arg), default: 3.0')
    parser.add_argument('--climb-rate', type=float, default=0.5,
                         help='Vertical speed while taking off / descending, m/s (default: 0.5)')
    parser.add_argument('--speed', type=float, default=1.0,
                         help='Max lateral speed, m/s (default: 1.0)')
    parser.add_argument('--tolerance', type=float, default=0.2,
                         help='Arrival radius, m (default: 0.2)')
    parser.add_argument('--hold', type=float, default=0.0,
                         help='Seconds to hover at each waypoint before moving on (default: 0.0)')
    parser.add_argument('--loop', action='store_true',
                         help='Repeat the waypoint route forever instead of stopping at the end')
    parser.add_argument('--kp', type=float, default=0.8,
                         help='Proportional gain on position error (default: 0.8)')
    args = parser.parse_args(argv)

    if len(args.coords) % 2 != 0:
        parser.error('coords must be given in x y pairs (even count)')

    args.waypoints = list(zip(args.coords[0::2], args.coords[1::2]))
    if args.altitude is None:
        args.altitude = args.spawn_altitude
    return args


class DronePatrol(Node):

    def __init__(self, args):
        super().__init__('drone_patrol')
        self.args = args
        self.waypoints = args.waypoints
        self.wp_index = 0
        self.hold_until = None

        self.x = None
        self.y = None
        self.qz = 0.0
        self.qw = 1.0

        self.entity_name = args.namespace
        self.z = args.spawn_altitude
        self.takeoff_done = abs(args.altitude - args.spawn_altitude) < 1e-3

        best_effort_qos = QoSProfile(depth=10, reliability=QoSReliabilityPolicy.BEST_EFFORT)

        self.cmd_pub = self.create_publisher(Twist, f'/{args.namespace}/cmd_vel', 10)
        self.odom_sub = self.create_subscription(
            Odometry, f'/{args.namespace}/odom', self.odom_cb, best_effort_qos)
        self.set_state_client = self.create_client(SetEntityState, '/gazebo/set_entity_state')

        direction = 'up' if args.altitude >= args.spawn_altitude else 'down'
        self.get_logger().info(
            f'Drone {args.namespace}: '
            + (f'taking off {direction} to {args.altitude:.1f}m, then ' if not self.takeoff_done else '')
            + f'patrolling {len(self.waypoints)} waypoint(s), loop={args.loop}, '
              f'speed<= {args.speed} m/s, tol={args.tolerance} m'
        )

        self.timer = self.create_timer(0.1, self.control_loop)

    def odom_cb(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        self.qz = msg.pose.pose.orientation.z
        self.qw = msg.pose.pose.orientation.w

    def stop(self):
        self.cmd_pub.publish(Twist())

    def set_altitude(self, z):
        """Kinematically set the drone's z via Gazebo, holding current x/y/yaw."""
        if not self.set_state_client.service_is_ready():
            return  # skip this tick; will retry next timer tick
        req = SetEntityState.Request()
        req.state = EntityState()
        req.state.name = self.entity_name
        req.state.pose.position.x = self.x
        req.state.pose.position.y = self.y
        req.state.pose.position.z = z
        req.state.pose.orientation.z = self.qz
        req.state.pose.orientation.w = self.qw
        req.state.reference_frame = 'world'
        self.set_state_client.call_async(req)
        self.z = z

    def control_loop(self):
        if self.x is None:
            return  # no odom yet

        if not self.takeoff_done:
            target_z = self.args.altitude
            step = self.args.climb_rate * 0.1  # per 0.1s timer tick
            if target_z > self.z:
                self.z = min(target_z, self.z + step)
            else:
                self.z = max(target_z, self.z - step)
            self.set_altitude(self.z)
            if abs(self.z - target_z) < 0.02:
                self.takeoff_done = True
                self.get_logger().info(f'Reached patrol altitude {target_z:.1f}m, starting route.')
            return

        if self.wp_index >= len(self.waypoints):
            if self.args.loop:
                self.wp_index = 0
            else:
                self.stop()
                self.get_logger().info('Patrol route complete.')
                self.timer.cancel()
                return

        tx, ty = self.waypoints[self.wp_index]
        ex, ey = tx - self.x, ty - self.y
        dist = (ex ** 2 + ey ** 2) ** 0.5

        if dist <= self.args.tolerance:
            self.stop()
            now = time.monotonic()
            if self.hold_until is None:
                self.hold_until = now + self.args.hold
                self.get_logger().info(
                    f'Reached waypoint {self.wp_index + 1}/{len(self.waypoints)} '
                    f'({tx:.2f}, {ty:.2f})'
                    + (f', holding {self.args.hold:.1f}s' if self.args.hold > 0 else '')
                )
            if now >= self.hold_until:
                self.hold_until = None
                self.wp_index += 1
            return

        vx = max(-self.args.speed, min(self.args.speed, self.args.kp * ex))
        vy = max(-self.args.speed, min(self.args.speed, self.args.kp * ey))

        cmd = Twist()
        cmd.linear.x = vx
        cmd.linear.y = vy
        self.cmd_pub.publish(cmd)


def main(args=None):
    # Split off ROS-specific args (after --ros-args) before argparse sees argv.
    raw = rclpy.utilities.remove_ros_args(sys.argv)[1:]
    parsed = parse_args(raw)

    rclpy.init(args=args)
    node = DronePatrol(parsed)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
