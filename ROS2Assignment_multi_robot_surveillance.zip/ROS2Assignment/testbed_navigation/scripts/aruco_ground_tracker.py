#!/usr/bin/env python3
"""
aruco_ground_tracker.py

Vision-based ground-robot localization for the drone: detects the ArUco
marker mounted flat on top of the ground robot (testbed.xacro,
aruco_marker_link, DICT_4X4_50 id 0) in the drone's downward-facing
camera, and publishes an estimated world-frame position for it. This is
what drone_follow.py tracks instead of subscribing to the ground robot's
odom directly.

Method (nadir camera, pinhole model):
  1. Detect the marker's 4 corners in the image; take the pixel centroid
     and principal-point offset (cu - cx, cv - cy).
  2. Use the drone's own altitude (from <drone_ns>/odom, z) as the
     camera-to-ground range -- the camera is rigidly mounted looking
     straight down, so range ~= altitude.
  3. Back-project the pixel offset to a metric ground-plane offset via
     similar triangles: offset_m = altitude * offset_px / focal_px.
     Focal length comes from the camera_info topic if available, else
     falls back to the horizontal_fov baked into drone.xacro.
  4. Map that camera-frame offset into world x/y (--invert-x/--invert-y
     let you correct the sign on first run -- see Notes) and add the
     drone's own world x/y to get the marker's world position.

Publishes:
  /<drone_ns>/aruco/ground_robot_position  (geometry_msgs/PointStamped)
        estimated world (x, y, 0) of the marker -- only meaningful when
        marker_visible is currently true (stale/frozen otherwise).
  /<drone_ns>/aruco/marker_visible         (std_msgs/Bool)
  /<drone_ns>/aruco/debug_image            (sensor_msgs/Image)
        camera feed with the detected marker outline + centroid drawn on
        it, for `ros2 run rqt_image_view rqt_image_view` sanity checks.

Usage:
    ros2 run testbed_navigation aruco_ground_tracker.py
    ros2 run testbed_navigation aruco_ground_tracker.py --drone-namespace drone --marker-id 0

Notes:
    - First run calibration: if drone_follow.py flies AWAY from the
      ground robot instead of toward it, the camera-to-world axis
      mapping is inverted for your Gazebo/camera frame convention --
      rerun this node with --invert-x and/or --invert-y until it
      converges correctly. Check with:
          ros2 topic echo /drone/aruco/ground_robot_position
      while nudging the ground robot and confirming the published x/y
      move the same direction.
    - Requires the drone's camera plugin publishing on
      /<drone_ns>/surveillance_camera/image_raw (already wired in
      drone.xacro) and the drone's own odom for altitude/position.
"""

import argparse
import sys

import cv2
import numpy as np
import rclpy
from cv_bridge import CvBridge
from geometry_msgs.msg import PointStamped
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy
from sensor_msgs.msg import CameraInfo, Image
from std_msgs.msg import Bool


def parse_args(argv):
    parser = argparse.ArgumentParser(
        description='Detect the ground robot ArUco marker in the drone camera and publish its world position.')
    parser.add_argument('--drone-namespace', default='drone',
                         help='Drone namespace used at spawn (default: drone)')
    parser.add_argument('--camera-name', default='surveillance_camera',
                         help='Camera name from drone.xacro (default: surveillance_camera)')
    parser.add_argument('--marker-id', type=int, default=0,
                         help='ArUco marker id to track (default: 0, matches aruco_marker_0.png)')
    parser.add_argument('--dictionary', default='DICT_4X4_50',
                         help='cv2.aruco predefined dictionary name (default: DICT_4X4_50)')
    parser.add_argument('--horizontal-fov', type=float, default=1.396,
                         help='Fallback horizontal FOV, rad, must match drone.xacro camera (default: 1.396)')
    parser.add_argument('--invert-x', action='store_true',
                         help='Flip the camera-frame-to-world x mapping (calibration, see Notes)')
    parser.add_argument('--invert-y', action='store_true',
                         help='Flip the camera-frame-to-world y mapping (calibration, see Notes)')
    parser.add_argument('--swap-xy', action='store_true',
                         help='Swap camera-frame x/y before mapping to world (calibration, see Notes)')
    return parser.parse_args(argv)


def get_aruco_detector(dictionary_name, marker_id):
    dict_id = getattr(cv2.aruco, dictionary_name)
    aruco_dict = cv2.aruco.getPredefinedDictionary(dict_id)

    # Support both the modern (opencv >= 4.7) ArucoDetector class and the
    # legacy free-function API (opencv 4.5.x, what Ubuntu 22.04 apt ships),
    # since which one is present has bitten this workspace before.
    if hasattr(cv2.aruco, 'ArucoDetector'):
        params = cv2.aruco.DetectorParameters()
        detector = cv2.aruco.ArucoDetector(aruco_dict, params)

        def detect(gray):
            corners, ids, _ = detector.detectMarkers(gray)
            return corners, ids
    else:
        params = cv2.aruco.DetectorParameters_create()

        def detect(gray):
            corners, ids, _ = cv2.aruco.detectMarkers(gray, aruco_dict, parameters=params)
            return corners, ids

    return detect


class ArucoGroundTracker(Node):

    def __init__(self, args):
        super().__init__('aruco_ground_tracker')
        self.args = args
        self.bridge = CvBridge()
        self.detect = get_aruco_detector(args.dictionary, args.marker_id)

        self.drone_x = None
        self.drone_y = None
        self.drone_z = None

        self.fx = None
        self.fy = None
        self.cx = None
        self.cy = None

        best_effort_qos = QoSProfile(depth=10, reliability=QoSReliabilityPolicy.BEST_EFFORT)

        self.drone_odom_sub = self.create_subscription(
            Odometry, f'/{args.drone_namespace}/odom', self.drone_odom_cb, best_effort_qos)
        self.info_sub = self.create_subscription(
            CameraInfo, f'/{args.drone_namespace}/{args.camera_name}/camera_info',
            self.camera_info_cb, best_effort_qos)
        self.image_sub = self.create_subscription(
            Image, f'/{args.drone_namespace}/{args.camera_name}/image_raw',
            self.image_cb, best_effort_qos)

        self.pos_pub = self.create_publisher(
            PointStamped, f'/{args.drone_namespace}/aruco/ground_robot_position', 10)
        self.visible_pub = self.create_publisher(
            Bool, f'/{args.drone_namespace}/aruco/marker_visible', 10)
        self.debug_pub = self.create_publisher(
            Image, f'/{args.drone_namespace}/aruco/debug_image', 1)

        self.get_logger().info(
            f'Tracking ArUco id={args.marker_id} ({args.dictionary}) in '
            f'/{args.drone_namespace}/{args.camera_name}/image_raw'
        )

    def drone_odom_cb(self, msg):
        self.drone_x = msg.pose.pose.position.x
        self.drone_y = msg.pose.pose.position.y
        self.drone_z = msg.pose.pose.position.z

    def camera_info_cb(self, msg):
        if msg.k[0] > 0.0:
            self.fx = msg.k[0]
            self.fy = msg.k[4]
            self.cx = msg.k[2]
            self.cy = msg.k[5]

    def image_cb(self, msg):
        if self.drone_x is None:
            return  # no drone odom (altitude) yet

        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape[:2]

        fx = self.fx if self.fx else w / (2.0 * np.tan(self.args.horizontal_fov / 2.0))
        fy = self.fy if self.fy else fx
        cx = self.cx if self.cx else w / 2.0
        cy = self.cy if self.cy else h / 2.0

        corners, ids = self.detect(gray)

        visible = False
        if ids is not None:
            for corner, marker_id in zip(corners, ids.flatten()):
                if marker_id != self.args.marker_id:
                    continue
                visible = True
                pts = corner.reshape(4, 2)
                cu, cv_ = pts[:, 0].mean(), pts[:, 1].mean()

                altitude = max(0.1, self.drone_z)  # avoid div/near-zero blowups pre-takeoff
                off_u = (cu - cx) / fx * altitude
                off_v = (cv_ - cy) / fy * altitude

                cam_dx, cam_dy = off_u, off_v
                if self.args.swap_xy:
                    cam_dx, cam_dy = cam_dy, cam_dx
                if self.args.invert_x:
                    cam_dx = -cam_dx
                if self.args.invert_y:
                    cam_dy = -cam_dy

                world_x = self.drone_x + cam_dx
                world_y = self.drone_y + cam_dy

                point = PointStamped()
                point.header.stamp = self.get_clock().now().to_msg()
                point.header.frame_id = 'map'
                point.point.x = world_x
                point.point.y = world_y
                point.point.z = 0.0
                self.pos_pub.publish(point)

                cv2.polylines(frame, [pts.astype(np.int32)], True, (0, 255, 0), 2)
                cv2.circle(frame, (int(cu), int(cv_)), 5, (0, 0, 255), -1)
                cv2.putText(frame, f'({world_x:.2f}, {world_y:.2f})', (int(cu) + 10, int(cv_)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
                break  # only tracking one marker id

        self.visible_pub.publish(Bool(data=visible))

        debug_msg = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
        debug_msg.header = msg.header
        self.debug_pub.publish(debug_msg)


def main(args=None):
    raw = rclpy.utilities.remove_ros_args(sys.argv)[1:]
    parsed = parse_args(raw)

    rclpy.init(args=args)
    node = ArucoGroundTracker(parsed)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
