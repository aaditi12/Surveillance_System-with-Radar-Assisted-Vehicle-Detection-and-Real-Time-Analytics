#!/usr/bin/env python3
"""
ground_nav_patrol.py

Full ground navigation via Nav2, driven from the CLI: sends waypoints
through the real Nav2 action stack (global planner, DWB local controller,
costmaps, recovery behaviors) instead of the direct cmd_vel P-controller
used by ground_patrol.py. This is the "real" autonomous navigation mode
-- it plans around obstacles using the costmap and will invoke recovery
behaviors (spin/backup/wait) if it gets stuck.

Requires, in separate terminals, in order:
    1. ros2 launch testbed_gazebo spawn_playground.launch.py     # Gazebo
    2. ros2 launch testbed_gazebo spawn_ground_robot.launch.py   # robot
    3. ros2 launch testbed_navigation localization.launch.py     # map_server + AMCL
    4. ros2 launch testbed_navigation navigation.launch.py       # planner/controller/BT
    5. (in RViz) set the "2D Pose Estimate" once so AMCL has an initial pose
       -- or pass --initial-pose below to set it from the CLI instead.

Usage examples:
    # visit waypoints in order (x y [yaw_deg] triples; yaw optional, default 0)
    ros2 run testbed_navigation ground_nav_patrol.py -- 0.0 5.0  3.0 5.0  3.0 -3.0

    # set AMCL's initial pose first (skip the RViz "2D Pose Estimate" click)
    ros2 run testbed_navigation ground_nav_patrol.py -- 3.0 5.0 --initial-pose 0 5 0

    # loop the route forever
    ros2 run testbed_navigation ground_nav_patrol.py -- 0 5  3 5  3 -3  0 -3 --loop

    # different robot namespace (must match navigation.launch.py's robot_name)
    ros2 run testbed_navigation ground_nav_patrol.py -- 0 5  3 5 --namespace other_robot

Notes:
    - Uses nav2_simple_commander's BasicNavigator, namespaced to match
      navigation.launch.py / localization.launch.py's robot_name (default
      "ground_robot"), so it targets /ground_robot/navigate_to_pose etc.
    - The leading "--" separates this script's own args from ROS args.
"""

import argparse
import math
import sys

import rclpy
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult


def parse_args(argv):
    parser = argparse.ArgumentParser(description='Full Nav2 waypoint navigation for the ground robot.')
    parser.add_argument('coords', nargs='+', type=float,
                         help='Flat list of goals as x1 y1 [yaw1] x2 y2 [yaw2] ... '
                              '(triples if yaw given, else pairs -- must be consistent)')
    parser.add_argument('--namespace', default='ground_robot',
                         help='Robot namespace, must match navigation.launch.py robot_name (default: ground_robot)')
    parser.add_argument('--loop', action='store_true',
                         help='Repeat the waypoint route forever instead of stopping at the end')
    parser.add_argument('--initial-pose', nargs=3, type=float, metavar=('X', 'Y', 'YAW_DEG'), default=None,
                         help='Set AMCL initial pose before navigating, instead of using RViz "2D Pose Estimate"')
    args = parser.parse_args(argv)

    n = len(args.coords)
    if n % 3 == 0 and n > 0:
        triples = list(zip(args.coords[0::3], args.coords[1::3], args.coords[2::3]))
    elif n % 2 == 0:
        triples = [(x, y, 0.0) for x, y in zip(args.coords[0::2], args.coords[1::2])]
    else:
        parser.error('coords must be given as x y pairs, or x y yaw_deg triples (consistent count)')
        return args

    args.goals = triples
    return args


def make_pose(navigator, x, y, yaw_deg):
    yaw = math.radians(yaw_deg)
    pose = PoseStamped()
    pose.header.frame_id = 'map'
    pose.header.stamp = navigator.get_clock().now().to_msg()
    pose.pose.position.x = x
    pose.pose.position.y = y
    pose.pose.orientation.z = math.sin(yaw / 2.0)
    pose.pose.orientation.w = math.cos(yaw / 2.0)
    return pose


def main():
    raw = rclpy.utilities.remove_ros_args(sys.argv)[1:]
    args = parse_args(raw)

    rclpy.init()
    navigator = BasicNavigator(namespace=f'/{args.namespace}')

    if args.initial_pose is not None:
        x, y, yaw_deg = args.initial_pose
        navigator.setInitialPose(make_pose(navigator, x, y, yaw_deg))

    navigator.info('Waiting for Nav2 to become active...')
    navigator.waitUntilNav2Active(localizer='amcl' if args.initial_pose is None else 'amcl')

    route = 0
    try:
        while True:
            route += 1
            navigator.info(f'--- Starting route pass {route} ({len(args.goals)} goal(s)) ---')
            for i, (x, y, yaw_deg) in enumerate(args.goals, start=1):
                goal_pose = make_pose(navigator, x, y, yaw_deg)
                navigator.info(f'Navigating to goal {i}/{len(args.goals)}: ({x:.2f}, {y:.2f}, {yaw_deg:.0f} deg)')
                navigator.goToPose(goal_pose)

                while not navigator.isTaskComplete():
                    feedback = navigator.getFeedback()
                    if feedback and int(feedback.navigation_time.sec) % 5 == 0:
                        navigator.info(
                            f'  remaining distance: {feedback.distance_remaining:.2f} m'
                        )

                result = navigator.getResult()
                if result == TaskResult.SUCCEEDED:
                    navigator.info(f'Goal {i} reached.')
                elif result == TaskResult.CANCELED:
                    navigator.info(f'Goal {i} canceled.')
                    return
                elif result == TaskResult.FAILED:
                    navigator.error(f'Goal {i} failed -- skipping to next waypoint.')

            if not args.loop:
                break

    except KeyboardInterrupt:
        navigator.cancelTask()

    navigator.info('Navigation route complete.')
    navigator.lifecycleShutdown()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
