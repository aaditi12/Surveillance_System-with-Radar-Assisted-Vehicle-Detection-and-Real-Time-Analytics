#!/usr/bin/env python3
"""
drone_follow.py

Surveillance mode for the drone: it tracks the ground robot and follows
it around continuously at a fixed altitude, directly overhead (or with an
optional standoff distance), instead of patrolling fixed waypoints or
sitting still watching one spot.

Two tracking sources, --source:
  model_states (default) -- reads the ground robot's true pose straight
      from Gazebo's /gazebo/model_states (published by the gazebo_ros_state
      world plugin already in the world file). Always available and never
      drops out, so the drone keeps following wherever the car goes,
      continuously, with no "lost track -> hover in place" fallback.
  aruco -- the original behaviour: visually tracks the ground robot's
      ArUco marker as detected by aruco_ground_tracker.py from the drone's
      downward camera. Kept for the vision-based demo, but camera-plugin
      frame sync on slower hosts can make detections intermittent, which
      is what previously made the drone stall/hover ("overwatch") instead
      of continuously following -- use model_states to avoid that.

While following it also publishes an "information screen" showing where
the ground robot currently is:

  - /surveillance/ground_robot_info  (std_msgs/String)
        one-line human-readable status, e.g.:
        "GROUND ROBOT @ (2.31, -1.04) [tracked]  |
         DRONE @ (2.10, -0.95) alt=6.0m  |  range=0.34m  bearing=142deg"
        echo it with:
            ros2 topic echo /surveillance/ground_robot_info

  - /surveillance/markers  (visualization_msgs/MarkerArray)
        a floating text label ("GROUND ROBOT") hovering above the ground
        robot's last-known position, plus a thin vertical line connecting
        the drone to the point on the ground directly below it. Red text
        turns grey when the marker is currently out of view. Add a
        MarkerArray display on this topic (already wired into
        testbed_description/rviz/full_bringup.rviz).

Same takeoff handling as drone_patrol.py: climbs kinematically via
Gazebo's /gazebo/set_entity_state to --altitude, holding gravity-disabled
altitude once reached, then closes a P-controller on x/y error to the
ground robot's tracked position (holonomic planar_move, so no heading
control is needed).

Usage examples:
    # follow directly overhead at 6m using ground-truth model_states (default)
    ros2 run testbed_navigation drone_follow.py --altitude 6.0

    # keep a lateral standoff instead of hovering right on top of it
    ros2 run testbed_navigation drone_follow.py --altitude 6.0 --standoff 2.0

    # vision-based ArUco tracking instead
    ros2 run testbed_navigation drone_follow.py --source aruco

    # different namespaces / spawn altitude / tuning
    ros2 run testbed_navigation drone_follow.py \\
        --drone-namespace drone --altitude 6.0 --spawn-altitude 3.0 --speed 1.2 --kp 0.8

Notes:
    - Requires both robots already spawned, e.g.:
        ros2 launch testbed_gazebo spawn_drone.launch.py
        ros2 launch testbed_gazebo spawn_ground_robot.launch.py
    - --source aruco additionally requires aruco_ground_tracker.py running
      (it does the actual camera-based detection):
        ros2 run testbed_navigation aruco_ground_tracker.py
    - Requires /gazebo/set_entity_state and /gazebo/model_states (both from
      the gazebo_ros_state world plugin).
    - In --source aruco mode, when the marker drops out of view (ground
      robot passes under an obstacle, camera FOV edge, etc.) the drone
      holds its last commanded target instead of chasing a stale position.
      --source model_states has no such gap.
"""

import argparse
import math
import sys

import rclpy
from gazebo_msgs.msg import EntityState, ModelStates
from gazebo_msgs.srv import SetEntityState
from geometry_msgs.msg import PointStamped, Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy
from std_msgs.msg import Bool, String
from visualization_msgs.msg import Marker, MarkerArray


def parse_args(argv):
    parser = argparse.ArgumentParser(
        description='Drone surveillance: follow the ground robot and report its position.')
    parser.add_argument('--drone-namespace', default='drone',
                         help='Drone namespace / robot_name used at spawn (default: drone)')
    parser.add_argument('--ground-entity', default='ground_robot',
                         help='Ground robot entity name in Gazebo, used for --source '
                              'model_states (default: ground_robot)')
    parser.add_argument('--source', choices=['model_states', 'aruco'], default='model_states',
                         help='Where to get the ground robot position from: ground-truth '
                              '/gazebo/model_states (default, always tracks -- no lost-track '
                              'hover), or aruco marker detection (default: model_states)')
    parser.add_argument('--marker-timeout', type=float, default=5.0,
                         help='(--source aruco only) If the marker stays unseen this long, '
                              'stop and hover in place instead of continuing toward the last '
                              'known position (default: 5.0)')
    parser.add_argument('--altitude', type=float, default=6.0,
                         help='Patrol/follow altitude, m (default: 6.0)')
    parser.add_argument('--spawn-altitude', type=float, default=3.0,
                         help='Altitude the drone was spawned at, m (default: 3.0)')
    parser.add_argument('--climb-rate', type=float, default=0.5,
                         help='Vertical speed while taking off, m/s (default: 0.5)')
    parser.add_argument('--standoff', type=float, default=0.0,
                         help='Lateral distance to keep from the ground robot instead of '
                              'hovering directly overhead, m (default: 0.0)')
    parser.add_argument('--speed', type=float, default=1.2,
                         help='Max lateral speed, m/s (default: 1.2)')
    parser.add_argument('--kp', type=float, default=0.8,
                         help='Proportional gain on position error (default: 0.8)')
    parser.add_argument('--report-rate', type=float, default=1.0,
                         help='Info-screen update rate, Hz (default: 1.0)')
    return parser.parse_args(argv)


class DroneFollow(Node):

    def __init__(self, args):
        super().__init__('drone_follow')
        self.args = args

        # drone state
        self.dx = None
        self.dy = None
        self.dqz = 0.0
        self.dqw = 1.0
        self.z = args.spawn_altitude
        self.takeoff_done = abs(args.altitude - args.spawn_altitude) < 1e-3

        # ground robot state -- from /gazebo/model_states (default) or the
        # ArUco tracker (aruco_ground_tracker.py), depending on --source
        self.gx = None
        self.gy = None
        self.marker_visible = False
        self.last_seen_time = None

        best_effort_qos = QoSProfile(depth=10, reliability=QoSReliabilityPolicy.BEST_EFFORT)

        self.cmd_pub = self.create_publisher(Twist, f'/{args.drone_namespace}/cmd_vel', 10)
        self.drone_odom_sub = self.create_subscription(
            Odometry, f'/{args.drone_namespace}/odom', self.drone_odom_cb, best_effort_qos)

        if args.source == 'model_states':
            self.model_states_sub = self.create_subscription(
                ModelStates, '/gazebo/model_states', self.model_states_cb, 10)
        else:
            self.aruco_pos_sub = self.create_subscription(
                PointStamped, f'/{args.drone_namespace}/aruco/ground_robot_position',
                self.aruco_pos_cb, best_effort_qos)
            self.aruco_visible_sub = self.create_subscription(
                Bool, f'/{args.drone_namespace}/aruco/marker_visible',
                self.aruco_visible_cb, best_effort_qos)

        self.set_state_client = self.create_client(SetEntityState, '/gazebo/set_entity_state')

        self.info_pub = self.create_publisher(String, '/surveillance/ground_robot_info', 10)
        self.marker_pub = self.create_publisher(MarkerArray, '/surveillance/markers', 10)

        if args.source == 'model_states':
            self.get_logger().info(
                f'Drone "{args.drone_namespace}" following ground robot '
                f'"{args.ground_entity}" via /gazebo/model_states (ground truth), '
                f'altitude={args.altitude}m, standoff={args.standoff}m.'
            )
        else:
            self.get_logger().info(
                f'Drone "{args.drone_namespace}" following the ground robot via ArUco marker '
                f'detection, altitude={args.altitude}m, standoff={args.standoff}m. '
                f'(requires aruco_ground_tracker.py running)'
            )

        self.control_timer = self.create_timer(0.1, self.control_loop)
        self.report_timer = self.create_timer(1.0 / args.report_rate, self.report_loop)

    def drone_odom_cb(self, msg):
        self.dx = msg.pose.pose.position.x
        self.dy = msg.pose.pose.position.y
        self.dqz = msg.pose.pose.orientation.z
        self.dqw = msg.pose.pose.orientation.w

    def model_states_cb(self, msg):
        try:
            idx = msg.name.index(self.args.ground_entity)
        except ValueError:
            return  # ground robot not spawned yet
        pose = msg.pose[idx]
        self.gx = pose.position.x
        self.gy = pose.position.y
        self.marker_visible = True
        self.last_seen_time = self.get_clock().now()

    def aruco_pos_cb(self, msg):
        self.gx = msg.point.x
        self.gy = msg.point.y
        self.last_seen_time = self.get_clock().now()

    def aruco_visible_cb(self, msg):
        self.marker_visible = msg.data

    def stop(self):
        self.cmd_pub.publish(Twist())

    def set_altitude(self, z):
        if not self.set_state_client.service_is_ready():
            return
        req = SetEntityState.Request()
        req.state = EntityState()
        req.state.name = self.args.drone_namespace
        req.state.pose.position.x = self.dx
        req.state.pose.position.y = self.dy
        req.state.pose.position.z = z
        req.state.pose.orientation.z = self.dqz
        req.state.pose.orientation.w = self.dqw
        req.state.reference_frame = 'world'
        self.set_state_client.call_async(req)
        self.z = z

    def control_loop(self):
        if self.dx is None or self.gx is None:
            return  # waiting on odom from one or both robots

        if not self.takeoff_done:
            target_z = self.args.altitude
            step = self.args.climb_rate * 0.1
            if target_z > self.z:
                self.z = min(target_z, self.z + step)
            else:
                self.z = max(target_z, self.z - step)
            self.set_altitude(self.z)
            if abs(self.z - target_z) < 0.02:
                self.takeoff_done = True
                self.get_logger().info(f'Reached follow altitude {target_z:.1f}m, tracking ground robot.')
            return

        # In --source aruco mode: if the marker's been unseen too long, hold
        # position instead of continuing to chase an increasingly stale
        # last-known point. --source model_states never hits this (it's
        # ground truth and always current as long as the robot is spawned).
        if self.args.source == 'aruco' and self.last_seen_time is not None:
            unseen_sec = (self.get_clock().now() - self.last_seen_time).nanoseconds / 1e9
            if unseen_sec > self.args.marker_timeout:
                self.stop()
                return

        # Target point: directly above the ground robot, or offset by
        # --standoff along the current line between the two if requested.
        ex, ey = self.gx - self.dx, self.gy - self.dy
        dist = math.hypot(ex, ey)

        if self.args.standoff > 0.0 and dist > 1e-3:
            ux, uy = ex / dist, ey / dist
            tx = self.gx - ux * self.args.standoff
            ty = self.gy - uy * self.args.standoff
            ex, ey = tx - self.dx, ty - self.dy

        vx = max(-self.args.speed, min(self.args.speed, self.args.kp * ex))
        vy = max(-self.args.speed, min(self.args.speed, self.args.kp * ey))

        cmd = Twist()
        cmd.linear.x = vx
        cmd.linear.y = vy
        self.cmd_pub.publish(cmd)

    def report_loop(self):
        if self.gx is None:
            return  # no fix yet at all

        stamp = self.get_clock().now().to_msg()
        drone_x = self.dx if self.dx is not None else 0.0
        drone_y = self.dy if self.dy is not None else 0.0
        range_m = math.hypot(self.gx - drone_x, self.gy - drone_y)
        bearing_deg = math.degrees(math.atan2(self.gy - drone_y, self.gx - drone_x))
        if self.args.source == 'model_states':
            visibility = 'tracked'
        else:
            visibility = 'marker visible' if self.marker_visible else 'marker NOT visible, last known position'

        status = (
            f'GROUND ROBOT @ ({self.gx:.2f}, {self.gy:.2f}) [{visibility}]  |  '
            f'DRONE @ ({drone_x:.2f}, {drone_y:.2f}) alt={self.z:.1f}m  |  '
            f'range={range_m:.2f}m  bearing={bearing_deg:.0f}deg'
        )
        self.info_pub.publish(String(data=status))
        self.get_logger().info(status)

        markers = MarkerArray()
        # red while actively tracking, grey once the marker's out of view
        r, g, b = (1.0, 0.2, 0.2) if self.marker_visible else (0.5, 0.5, 0.5)

        label = Marker()
        label.header.frame_id = 'map'
        label.header.stamp = stamp
        label.ns = 'surveillance'
        label.id = 0
        label.type = Marker.TEXT_VIEW_FACING
        label.action = Marker.ADD
        label.pose.position.x = self.gx
        label.pose.position.y = self.gy
        label.pose.position.z = 1.2
        label.scale.z = 0.4
        label.color.r, label.color.g, label.color.b = r, g, b
        label.color.a = 1.0
        tag = 'GROUND ROBOT' if self.marker_visible else 'GROUND ROBOT (last seen)'
        label.text = f'{tag}\n({self.gx:.2f}, {self.gy:.2f})'
        markers.markers.append(label)

        sightline = Marker()
        sightline.header.frame_id = 'map'
        sightline.header.stamp = stamp
        sightline.ns = 'surveillance'
        sightline.id = 1
        sightline.type = Marker.LINE_STRIP
        sightline.action = Marker.ADD
        sightline.scale.x = 0.05
        sightline.color.r, sightline.color.g, sightline.color.b = (1.0, 0.8, 0.0) if self.marker_visible else (0.5, 0.5, 0.5)
        sightline.color.a = 0.8
        p_drone = _point(drone_x, drone_y, self.z)
        p_ground = _point(self.gx, self.gy, 0.05)
        sightline.points = [p_drone, p_ground]
        markers.markers.append(sightline)

        self.marker_pub.publish(markers)


def _point(x, y, z):
    from geometry_msgs.msg import Point
    p = Point()
    p.x, p.y, p.z = x, y, z
    return p


def main(args=None):
    raw = rclpy.utilities.remove_ros_args(sys.argv)[1:]
    parsed = parse_args(raw)

    rclpy.init(args=args)
    node = DroneFollow(parsed)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()

