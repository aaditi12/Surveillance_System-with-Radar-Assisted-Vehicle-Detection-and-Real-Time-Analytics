#!/usr/bin/env python3

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction
from launch.substitutions import Command, FindExecutable, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node, PushRosNamespace
from launch_ros.substitutions import FindPackageShare
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    robot_name = LaunchConfiguration('robot_name')

    robot_description_content = Command([
        PathJoinSubstitution([FindExecutable(name="xacro")]),
        " ",
        PathJoinSubstitution([
            FindPackageShare("testbed_description"),
            "urdf",
            "testbed.xacro",
        ]),
        " ",
        "robot_name:=", robot_name,
    ])

    robot_description = {
        "robot_description": ParameterValue(robot_description_content, value_type=str)
    }

    # GroupAction scopes PushRosNamespace to just the node(s) inside it, so the
    # namespace push does NOT leak onto sibling actions/includes launched
    # afterwards by a parent launch file (e.g. spawn_entity in spawn_testbed.launch.py).
    namespaced_rsp = GroupAction([
        PushRosNamespace(robot_name),
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[robot_description, {'use_sim_time': True}]),
    ])

    return LaunchDescription([
        DeclareLaunchArgument(
            'robot_name',
            default_value='ground_robot',
            description='Namespace / TF-prefix for the ground robot'),

        namespaced_rsp,
    ])
